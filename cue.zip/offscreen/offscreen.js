// Captures the meeting tab's audio, cuts it into spoken phrases, sends each to the backend for transcription.
// Tab audio is muted for the user by Chrome while captured, so it is routed back to the speakers here.
const SR = 16000, HANG_MS = 600, MAX_MS = 12000, MIN_MS = 350, THRESH = 0.012;
// Offscreen documents can only use chrome.runtime (no chrome.storage), so the service worker hands us the backend URL and token.
let state = { tabId: null, session: '', paused: false, backend: '', token: '', lang: 'auto' };
let stream, playCtx, capCtx, node;
let chunks = [], pre = [], speechMs = 0, silenceMs = 0, totalMs = 0, queue = Promise.resolve();

chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m.target !== 'offscreen') return;
  if (m.type === 'init') { init(m).then(() => reply({ ok: true }), e => reply({ ok: false, error: e.message })); return true; }
  if (m.type === 'pause') { state.paused = m.paused; reset(); }
});

async function init({ streamId, tabId, session, backend, token, lang }) {
  teardown();
  state = { tabId, session, paused: false, backend, token, lang: lang || 'auto' };
  stream = await navigator.mediaDevices.getUserMedia({ audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } } });
  playCtx = new AudioContext();
  playCtx.createMediaStreamSource(stream).connect(playCtx.destination);
  capCtx = new AudioContext({ sampleRate: SR });
  await capCtx.audioWorklet.addModule('capture-worklet.js');
  node = new AudioWorkletNode(capCtx, 'cue-capture');
  node.port.onmessage = e => onAudio(e.data);
  capCtx.createMediaStreamSource(stream).connect(node);
  node.connect(capCtx.destination); // keeps the node pulled by the graph; it outputs silence
  // A context created without a user gesture can start suspended, which would capture nothing.
  await Promise.all([playCtx.resume(), capCtx.resume()]);
}

function teardown() {
  try { node && (node.port.onmessage = null); stream && stream.getTracks().forEach(t => t.stop()); playCtx && playCtx.close(); capCtx && capCtx.close(); } catch (_) {}
  stream = playCtx = capCtx = node = null; reset();
}

function reset() { chunks = []; pre = []; speechMs = silenceMs = totalMs = 0; }

function onAudio(d) {
  if (state.paused) return;
  const ms = (d.length / SR) * 1000;
  let sum = 0; for (let i = 0; i < d.length; i++) sum += d[i] * d[i];
  const loud = Math.sqrt(sum / d.length) > THRESH;
  if (!chunks.length) {
    if (loud) { chunks = [...pre, d]; speechMs = totalMs = ms; silenceMs = 0; pre = []; }
    else { pre.push(d); if (pre.length > 2) pre.shift(); }
    return;
  }
  chunks.push(d); totalMs += ms;
  if (loud) { speechMs += ms; silenceMs = 0; } else silenceMs += ms;
  if (silenceMs >= HANG_MS || totalMs >= MAX_MS) {
    const c = chunks, sp = speechMs; reset();
    if (sp >= MIN_MS) queue = queue.then(() => transcribe(c)); // queue keeps phrases in order
  }
}

function wav(chunks) {
  const n = chunks.reduce((a, c) => a + c.length, 0), buf = new DataView(new ArrayBuffer(44 + n * 2));
  const w = (o, s) => [...s].forEach((ch, i) => buf.setUint8(o + i, ch.charCodeAt(0)));
  w(0, 'RIFF'); buf.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); buf.setUint32(16, 16, true); buf.setUint16(20, 1, true);
  buf.setUint16(22, 1, true); buf.setUint32(24, SR, true); buf.setUint32(28, SR * 2, true); buf.setUint16(32, 2, true); buf.setUint16(34, 16, true);
  w(36, 'data'); buf.setUint32(40, n * 2, true);
  let o = 44; for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) buf.setInt16(o, Math.max(-1, Math.min(1, c[i])) * 0x7fff, true);
  return new Blob([buf], { type: 'audio/wav' });
}

async function transcribe(c) {
  try {
    const fd = new FormData(); fd.append('audio', wav(c), 'speech.wav'); fd.append('lang', state.lang);
    let r;
    try { r = await fetch(state.backend + '/api/transcribe', { method: 'POST', body: fd, headers: { Authorization: 'Bearer ' + state.token, 'X-Cue-Session': state.session } }); }
    catch { const e = new Error('Cannot reach the Cue backend. Is it running?'); e.code = 'offline'; throw e; }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(j.error || 'Transcription failed.'); e.code = j.code; throw e; }
    if (j.text) chrome.runtime.sendMessage({ type: 'transcript', tabId: state.tabId, text: j.text });
  } catch (e) {
    if (e.code === 'paused') return; // a phrase that was in flight when the user paused
    chrome.runtime.sendMessage({ type: 'capture:error', tabId: state.tabId, error: e.message, code: e.code });
    if (e.code === 'credits' || e.code === 'session') { state.paused = true; reset(); }
  }
}
