// Question and situation detector. Pure heuristics, no network. REAL.
(function (root) {
  const EXPLICIT = /^(so,?\s+|and,?\s+|okay,?\s+)?(what|why|how|when|where|who|which|can you|could you|would you|do you|did you|have you|are you|were you|is there|tell me|describe|explain|give me|share|talk me through|walk me through|take me through)\b/i;
  const IMPLICIT = /(i'?d like to (understand|hear|know|learn)|i would like to (understand|hear|know)|let'?s say|suppose|imagine|assume|i'?m curious|help me understand|what if|walk me through|talk me through)/i;
  const MEETING = {
    decision: /(should we|do we (go|move|ship|proceed)|which option|can we decide|your call|go or no.?go|are we (good|aligned))/i,
    opinion: /(what do you think|your (thoughts|opinion|take)|do you agree|how do you feel|any thoughts)/i,
    objection: /(i'?m not (sure|convinced)|i don'?t think|my concern|worried|too (expensive|risky|slow)|won'?t work|the problem is|but what about)/i,
    task: /(can you (take|own|handle|send|follow up|prepare|set up)|could you (send|share|follow up|prepare)|action item|i'?ll need you to|by (monday|tuesday|wednesday|thursday|friday|tomorrow|eod|end of (day|week)))/i,
  };
  // Hindi puts question words mid-sentence ("आपने यह क्यों किया"), so these match anywhere, not just at the start.
  // \b does not work on Devanagari, so word edges are spaces, punctuation or the ends of the text.
  const HI_DEV = /(^|[\s,"'])(क्या|क्यों|क्यूं|कैसे|कैसा|कैसी|कब|कहाँ|कहां|कौन|किस|कितन[ाेी]|बताइए|बताइये|बताओ|बताएं|बताएँ|बताएंगे|बताएँगे|समझाइए|समझाओ|सकते हैं|सकती हैं|सकते हो)(?=$|[\s,?!.।"'])/;
  const HI_LAT = /\b(kya|kyu|kyun|kyon|kaise|kaisa|kaisi|kab|kahan|kaun|kis|kitna|kitne|kitni|batao|bataiye|bataiye|batayiye|batayein|bataenge|samjhao|samjhaiye|sakte ho|sakte hain|ke baare mein)\b/i;
  // Coding asks are usually imperatives ("Write a program...", "Reverse a linked list"), not questions.
  const CODE_THING = '(code|function|program|script|query|sql|class|method|algorithm|logic|api|snippet)';
  const DSA = '(array|string|linked list|list|tree|binary|graph|stack|queue|hash ?map|dictionary|matrix|number|integer|fibonacci|palindrome|prime|factorial|anagram|duplicates?|substring|subarray)';
  const CODE = [
    new RegExp('\\b(write|implement|code up|program|give me|show me|share|create|build)\\b.{0,60}\\b' + CODE_THING + '\\b', 'i'),
    new RegExp('\\b(let\'?s|let us|we\'?ll|we will|time to|now)\\s+(do\\s+)?(some\\s+|a\\s+)?(coding|code|live coding)\\b', 'i'),
    new RegExp('(^|[.?!]\\s+|\\b(want|need|like) you to\\s+|\\bplease\\s+|\\b(can|could|would) you\\s+)(write|implement|reverse|sort|find|print|check|merge|detect|remove|count|return|design|convert|validate)\\b.{0,80}\\b' + DSA + '\\b', 'i'),
    new RegExp('\\b' + CODE_THING + '\\s*(likh|likho|likhiye|likhna|likhiyega|bana|banao|banaiye)', 'i'),
    /(कोड|प्रोग्राम|फंक्शन|फ़ंक्शन|क्वेरी)[^।?]{0,40}(लिख|बना)/,
  ];
  const LABEL = { code: 'Code', question: 'Question', opinion: 'Suggested response', decision: 'Recommendation', objection: 'Possible response', task: 'Action item detected' };
  // Sentences ending on these words are almost always unfinished.
  const DANGLING = /\b(and|or|but|so|with|that|to|of|for|in|on|about|where|when|how|the|a|an|your|you|had|have|is|are|was|were|if|because)\s*$/i;
  const DANGLING_HI = /(^|\s)(और|या|लेकिन|कि|के|की|का|में|से|को|पर|aur|ya|lekin|ki|ke|ka|mein|se|ko|par)\s*$/i;

  function classify(text, mode) {
    const t = (text || '').trim();
    if (t.split(/\s+/).length < 3) return { isQuestion: false };
    if (mode === 'meeting') {
      for (const k of ['task', 'decision', 'objection', 'opinion']) if (MEETING[k].test(t)) return { isQuestion: true, kind: k, label: LABEL[k] };
    }
    if (CODE.some(r => r.test(t))) return { isQuestion: true, kind: 'code', label: LABEL.code };
    const last = t.split(/(?<=[.?!।])\s+/).pop();
    if (/\?\s*$/.test(t) || EXPLICIT.test(last) || EXPLICIT.test(t)) return { isQuestion: true, kind: 'question', label: LABEL.question };
    if (IMPLICIT.test(t)) return { isQuestion: true, kind: 'question', label: LABEL.question };
    if (HI_DEV.test(t) || HI_LAT.test(t)) return { isQuestion: true, kind: 'question', label: LABEL.question };
    return { isQuestion: false };
  }

  // How long to wait for more speech before treating the buffer as one finished question.
  function settleDelay(text) {
    const t = (text || '').trim();
    const bare = t.replace(/[.,।]$/, '');
    if (DANGLING.test(bare) || DANGLING_HI.test(bare)) return 2200;
    if (/\?\s*$/.test(t)) return 200;
    if (/[.!।]\s*$/.test(t)) return 800;
    return 1500;
  }

  root.CueDetector = { classify, settleDelay };
  if (typeof module !== 'undefined') module.exports = root.CueDetector;
})(typeof window !== 'undefined' ? window : globalThis);
