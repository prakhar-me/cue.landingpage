// Deployed backend. For local development, set Settings > Backend URL to http://localhost:8787 instead of editing this.
// Keep the same origin in host_permissions in manifest.json.
self.CUE_CONFIG = { backend: 'https://cue-backend-j1f7.onrender.com' };
