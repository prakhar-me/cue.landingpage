// Sessions and documents kept in chrome.storage.local, shared by the options page, popup, overlay and mock page.
// Session: { id, title, company, role, mode: 'interview'|'call'|'mock', lang, plannedMinutes, instructions, saveTranscript,
//            status: 'ready'|'live'|'ended', createdAt, startedAt, endedAt, durationMs, creditsUsed, serverSessionId,
//            tabId, armedAt, transcript, notes, ask }
// Document: { id, name, kind: 'resume'|'notes'|'playbook'|'other', text, addedAt }
(function (root) {
  const get = k => new Promise(r => chrome.storage.local.get(k, r));
  const set = o => new Promise(r => chrome.storage.local.set(o, r));
  const MAX_SESSIONS = 100;
  const MODE_LABEL = { interview: 'Interview', call: 'Regular call', mock: 'Mock interview' };

  // Older versions kept a history list without status; turn those into ended sessions.
  function upgrade(s) {
    if (s.status) return s;
    return { id: s.id, title: s.title, mode: s.mode === 'meeting' ? 'call' : 'interview', lang: 'auto', plannedMinutes: null, instructions: '',
      saveTranscript: Boolean(s.transcript), status: 'ended', createdAt: s.created, startedAt: s.created, endedAt: s.created + (s.durationMs || 0),
      durationMs: s.durationMs || 0, creditsUsed: s.credits ?? null, transcript: s.transcript || null, notes: s.notes || '', ask: [] };
  }

  async function list() {
    const { sessions = [] } = await get('sessions');
    const out = sessions.map(upgrade);
    // A session left "live" by a closed tab or crashed page for over 12 hours is shown as ended.
    out.forEach(s => { if (s.status === 'live' && Date.now() - (s.startedAt || 0) > 12 * 3600_000) s.status = 'ended'; });
    return out;
  }
  const save = sessions => set({ sessions: sessions.slice(0, MAX_SESSIONS) });

  async function getOne(id) { return (await list()).find(s => s.id === id) || null; }

  async function create(fields) {
    const s = { id: 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: 'Untitled session', company: '', role: '',
      mode: 'interview', lang: 'auto', plannedMinutes: 30, instructions: '', saveTranscript: false, status: 'ready',
      createdAt: Date.now(), transcript: null, notes: '', ask: [], ...fields };
    const all = await list(); all.unshift(s); await save(all);
    return s;
  }

  async function update(id, patch) {
    const all = await list(), i = all.findIndex(s => s.id === id);
    if (i < 0) return null;
    all[i] = { ...all[i], ...(typeof patch === 'function' ? patch(all[i]) : patch) };
    await save(all);
    return all[i];
  }

  async function remove(id) { await save((await list()).filter(s => s.id !== id)); }

  // ---- Documents ----
  async function docs() {
    const { docs = null, context = {} } = await get(['docs', 'context']);
    if (docs) return docs;
    // First run after the update: the old single resume becomes a document.
    const first = context.resume ? [{ id: 'd' + Date.now().toString(36), name: 'Resume', kind: 'resume', text: context.resume, addedAt: Date.now() }] : [];
    await set({ docs: first });
    return first;
  }
  const saveDocs = d => set({ docs: d });

  root.CueSessions = { list, get: getOne, create, update, remove, docs, saveDocs, MODE_LABEL };
})(typeof self !== 'undefined' ? self : window);
