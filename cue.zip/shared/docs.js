// Picks the parts of the user's documents that matter for the current question, so long notes and
// playbooks can be used without sending everything on every request. Pure functions, no network.
(function (root) {
  const STOP = new Set('the and for are but not you your with that this have from they will what when where which who how why can could would should about into than then them there their were been being does did done also just only very more most some such like want tell give make take know think said says say been our out over under again once here each both few other same too any all its ive dont cant was has had his her him she hes shes yes kya hai hain aur bhi kar karo kaise kyun main mein mujhe aap aapka aapki ki ka ke ko se par ye wo'.split(' '));
  const words = t => (t.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu) || []).filter(w => !STOP.has(w));

  // Paragraph-sized chunks of about `size` characters, never splitting mid-paragraph unless one is huge.
  function chunks(text, size = 700) {
    const out = []; let cur = '';
    for (const para of String(text).split(/\n\s*\n/)) {
      const p = para.trim(); if (!p) continue;
      if (p.length > size * 1.5) { if (cur) { out.push(cur); cur = ''; } for (let i = 0; i < p.length; i += size) out.push(p.slice(i, i + size)); continue; }
      if (cur && cur.length + p.length > size) { out.push(cur); cur = ''; }
      cur = cur ? cur + '\n\n' + p : p;
    }
    if (cur) out.push(cur);
    return out;
  }

  // docs: [{ name, text }]. Returns excerpts ("[name] text") that fit in `budget` characters.
  // Small document sets are sent whole; larger ones are ranked by word overlap with the query (tf-idf style).
  function relevant(docs, query, budget = 4000) {
    const all = [];
    docs.forEach(d => chunks(d.text).forEach(c => all.push({ name: d.name, text: c })));
    if (!all.length) return [];
    const total = all.reduce((n, c) => n + c.text.length, 0);
    if (total <= budget) return all.map(c => `[${c.name}] ${c.text}`);
    const q = [...new Set(words(query))];
    if (!q.length) return [];
    const bags = all.map(c => { const m = new Map(); words(c.text).forEach(w => m.set(w, (m.get(w) || 0) + 1)); return m; });
    const df = new Map(q.map(w => [w, bags.filter(b => b.has(w)).length]));
    const scored = all.map((c, i) => ({ c, score: q.reduce((s, w) => s + (bags[i].has(w) ? (1 + Math.log(bags[i].get(w))) * Math.log(1 + all.length / df.get(w)) : 0), 0) }))
      .filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    const out = []; let used = 0;
    for (const { c } of scored) { if (used + c.text.length > budget) continue; out.push(`[${c.name}] ${c.text}`); used += c.text.length; }
    return out;
  }

  root.CueDocs = { relevant, chunks, words };
  if (typeof module !== 'undefined') module.exports = root.CueDocs;
})(typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : globalThis);
