// Account, pricing and API helpers shared by the service worker, popup, options and offscreen pages.
(function (root) {
  const cfg = root.CUE_CONFIG || { backend: 'http://localhost:8787' };

  async function backend() {
    const { settings = {} } = await chrome.storage.local.get('settings');
    return (settings.backend || cfg.backend).replace(/\/+$/, '');
  }

  class ApiError extends Error { constructor(msg, code, status) { super(msg); this.code = code; this.status = status; } }

  // One device account per browser. The lock stops two pages creating two accounts on first run.
  // Accounts live on one backend. A token made on another backend (e.g. localhost during development)
  // is unknown to this one, so a new account is created instead. Older saved tokens predate this field.
  const LEGACY = 'http://localhost:8787';
  const ours = (a, b) => a && a.token && (a.backend || LEGACY).replace(/\/+$/, '') === b;

  async function token() {
    const b = await backend();
    const { account } = await chrome.storage.local.get('account');
    if (ours(account, b)) return account.token;
    return navigator.locks.request('cue-account', async () => {
      const again = (await chrome.storage.local.get('account')).account;
      if (ours(again, b)) return again.token;
      let r;
      try { r = await fetch(b + '/api/account', { method: 'POST' }); }
      catch { throw new ApiError('Cannot reach the Cue backend. Is it running?', 'offline'); }
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new ApiError(j.error || 'Could not create your Cue account.', j.code, r.status);
      await chrome.storage.local.set({ account: { token: j.token, createdAt: Date.now(), backend: b } });
      return j.token;
    });
  }

  async function authFetch(path, init = {}, session) {
    const t = await token();
    const headers = { ...(init.headers || {}), Authorization: 'Bearer ' + t, ...(session ? { 'X-Cue-Session': session } : {}) };
    try { return await fetch((await backend()) + path, { ...init, headers }); }
    catch (e) { if (e.name === 'AbortError') throw e; throw new ApiError('Cannot reach the Cue backend. Is it running?', 'offline'); }
  }

  async function api(path, { method, body, session } = {}) {
    const r = await authFetch(path, {
      method: method || (body ? 'POST' : 'GET'),
      headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined,
    }, session);
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new ApiError(j.error || `Backend returned ${r.status}`, j.code, r.status);
    return j;
  }

  // Mirrors backend/src/billing/pricing.js so the popup can quote instantly. The server re-checks every order.
  const dur = min => {
    const h = Math.floor(min / 60), m = min % 60;
    if (!h) return `${m} min`;
    if (!m) return `${h} hr${h > 1 ? 's' : ''}`;
    if (m === 30) return `${h}.5 hrs`;
    return `${h} hr${h > 1 ? 's' : ''} ${m} min`;
  };
  const rupees = p => '₹' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: p % 100 ? 2 : 0, maximumFractionDigits: 2 });
  // Cheapest way to buy at least `need` credits: a pack, or pay as you go with the minimum purchase.
  function cheapestBuy(need, p) {
    if (need <= 0) return null;
    const credits = Math.max(need, p.minPurchaseCredits || 1);
    let best = { pack: null, credits, pricePaise: credits * p.pricePerCreditPaise, label: `${credits} credits` };
    for (const k of p.packs || []) if (k.credits >= need && k.pricePaise <= best.pricePaise) best = { pack: k.id, credits: k.credits, pricePaise: k.pricePaise, label: `${k.name} pack, ${k.credits} credits` };
    return best;
  }
  function quote(minutes, balance, p) {
    const credits = Math.ceil(minutes / p.creditMinutes), buy = cheapestBuy(credits - balance, p);
    return { minutes, credits, amountPaise: credits * p.pricePerCreditPaise, buy, toBuy: buy ? buy.credits : 0, toBuyPaise: buy ? buy.pricePaise : 0,
      summary: `${dur(minutes)} = ${credits} credits = ${rupees(credits * p.pricePerCreditPaise)}` };
  }
  // What to send to /api/billing/order for a buy option.
  const orderBody = buy => (buy.pack ? { pack: buy.pack } : { credits: buy.credits });
  const left = ms => {
    const s = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}:${String(s % 60).padStart(2, '0')}`;
  };

  root.CueClient = { backend, token, authFetch, api, ApiError, quote, cheapestBuy, orderBody, dur, rupees, left };
})(self);
