(function (root) {
  const I = {
    gear: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="2.2"/><path d="M8 1.8v1.6M8 12.6v1.6M1.8 8h1.6M12.6 8h1.6M3.6 3.6l1.1 1.1M11.3 11.3l1.1 1.1M3.6 12.4l1.1-1.1M11.3 4.7l1.1-1.1"/></svg>',
    min: '<svg viewBox="0 0 16 16"><path d="M3.5 8h9"/></svg>',
    copy: '<svg viewBox="0 0 16 16"><rect x="5.5" y="5.5" width="7" height="8" rx="1.5"/><path d="M10.5 3.5h-6a1 1 0 0 0-1 1v7"/></svg>',
    check: '<svg viewBox="0 0 16 16"><path d="M3.5 8.5l3 3 6-7"/></svg>',
    answer: '<svg viewBox="0 0 16 16"><path d="M8 1.5l1.7 4.8 4.8 1.7-4.8 1.7L8 14.5l-1.7-4.8L1.5 8l4.8-1.7z"/></svg>',
    shot: '<svg viewBox="0 0 16 16"><rect x="1.5" y="4" width="13" height="9.5" rx="2"/><circle cx="8" cy="8.7" r="2.4"/><path d="M5.5 4l1-1.8h3l1 1.8"/></svg>',
    chat: '<svg viewBox="0 0 16 16"><path d="M2.5 3.5h11v7h-6l-3 2.5v-2.5h-2z"/></svg>',
    end: '<svg viewBox="0 0 16 16"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    send: '<svg viewBox="0 0 16 16"><path d="M2.5 8h10M9 4.5L12.5 8 9 11.5"/></svg>',
    mark: '<svg viewBox="0 0 10 10" class="mk"><circle class="o" cx="1" cy="1" r=".55"/><circle cx="3" cy="1" r=".85"/><circle cx="5" cy="1" r=".85"/><circle cx="7" cy="1" r=".85"/><circle class="o" cx="9" cy="1" r=".55"/><circle cx="1" cy="3" r=".85"/><circle class="o" cx="3" cy="3" r=".55"/><circle class="o" cx="5" cy="3" r=".55"/><circle class="o" cx="7" cy="3" r=".55"/><circle class="o" cx="9" cy="3" r=".55"/><circle cx="1" cy="5" r=".85"/><circle class="o" cx="3" cy="5" r=".55"/><circle class="o" cx="5" cy="5" r=".55"/><circle class="o" cx="7" cy="5" r=".55"/><circle class="r" cx="9" cy="5" r=".85"/><circle cx="1" cy="7" r=".85"/><circle class="o" cx="3" cy="7" r=".55"/><circle class="o" cx="5" cy="7" r=".55"/><circle class="o" cx="7" cy="7" r=".55"/><circle class="o" cx="9" cy="7" r=".55"/><circle class="o" cx="1" cy="9" r=".55"/><circle cx="3" cy="9" r=".85"/><circle cx="5" cy="9" r=".85"/><circle cx="7" cy="9" r=".85"/><circle class="o" cx="9" cy="9" r=".55"/></svg>',
  };

  const CSS = `
  :host{all:initial}
  *{box-sizing:border-box;margin:0}
  [hidden]{display:none!important}
  .cue{--op:.4;--ink:#f2f2f2;--ink2:#cfcfcf;--mute:#8f8f8f;--line:rgba(255,255,255,.12);--line2:rgba(255,255,255,.22);--red:#ff3b30;
    --base:5,5,5;--field:rgba(0,0,0,.35);--soft:rgba(255,255,255,.07);--code:rgba(0,0,0,.5);--dot:rgba(255,255,255,.06);
    --dm:CueDoto,"Space Mono",ui-monospace,monospace;--mono:CueMono,ui-monospace,SFMono-Regular,Menlo,monospace;
    --sans:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
    position:fixed;right:24px;bottom:24px;width:424px;z-index:2147483647;color:var(--ink);
    font:13.5px/1.55 var(--sans);-webkit-font-smoothing:antialiased;
    transition:opacity .22s ease,transform .26s cubic-bezier(.2,.8,.2,1),visibility 0s}
  .cue.light{--ink:#141414;--ink2:#333;--mute:#6b6b6b;--line:rgba(0,0,0,.12);--line2:rgba(0,0,0,.22);
    --base:250,250,250;--field:rgba(255,255,255,.7);--soft:rgba(0,0,0,.05);--code:rgba(0,0,0,.06);--dot:rgba(0,0,0,.05)}
  .cue.hidden{opacity:0;transform:translateY(10px) scale(.98);visibility:hidden;pointer-events:none;transition:opacity .18s ease,transform .18s ease,visibility 0s .18s}
  .cue.snap{visibility:hidden!important;transition:none!important}
  .cue.drag{transition:none}
  @keyframes pop{from{opacity:0;transform:translateY(8px) scale(.97)}}
  @keyframes drop{from{opacity:0;transform:translateY(-4px)}}
  @keyframes in{from{opacity:0;transform:translateY(6px)}}
  @keyframes fade{from{opacity:0}}
  @keyframes led{0%,100%{opacity:1}50%{opacity:.15}}
  .card{position:relative;border-radius:18px;overflow:hidden;
    background:radial-gradient(var(--dot) 1px,transparent 1.3px) 0 0/7px 7px,rgba(var(--base),calc(var(--op) + .3));
    backdrop-filter:blur(20px) saturate(120%);-webkit-backdrop-filter:blur(20px) saturate(120%);
    border:1px solid var(--line);box-shadow:0 18px 50px -12px rgba(0,0,0,.55);transform-origin:100% 100%;animation:pop .28s cubic-bezier(.2,.8,.2,1)}
  svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;flex:none}
  svg.mk{stroke:none;fill:var(--ink);width:16px;height:16px}svg.mk .o{fill:var(--line2)}svg.mk .r{fill:var(--red)}
  .head{display:flex;align-items:center;gap:8px;padding:10px 8px 8px 14px;cursor:grab;user-select:none;touch-action:none}
  .head:active{cursor:grabbing}
  .brand{display:flex;align-items:center;gap:7px;font:800 18px/1 var(--dm);letter-spacing:.05em}
  .timer{font:600 13px/1 var(--sans);font-variant-numeric:tabular-nums;color:var(--ink2)}
  .left{padding:3px 9px;border-radius:99px;border:1px solid var(--line);color:var(--mute);font:500 11.5px/1.2 var(--sans);font-variant-numeric:tabular-nums;white-space:nowrap;transition:color .2s,background .2s,border-color .2s}
  .left:empty{display:none}.left.warn{color:#fff;border-color:var(--red);background:rgba(255,59,48,.85)}
  .led{width:7px;height:7px;border-radius:50%;background:var(--mute);flex:none}
  .live .led{background:var(--red);box-shadow:0 0 6px rgba(255,59,48,.7);animation:led 1.1s steps(1) infinite}
  .think .led{background:var(--ink);animation:led .6s steps(1) infinite}
  .sp{flex:1}
  .ib{all:unset;display:grid;place-items:center;width:28px;height:28px;border-radius:99px;color:var(--mute);cursor:pointer;transition:background .12s,color .12s,transform .1s}
  .ib:hover{background:var(--soft);color:var(--ink)}.ib:active{transform:scale(.9)}
  :focus-visible{outline:2px solid var(--red);outline-offset:2px}
  .status{padding:0 14px 6px;color:var(--mute);font-size:11.5px}
  .feed{padding:2px 14px 6px;max-height:44vh;overflow:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:var(--line2) transparent}
  .empty{color:var(--mute);font-size:12.5px;padding:18px 0;text-align:center}
  .msg{padding:10px 0 12px;border-top:1px solid var(--line);animation:in .28s cubic-bezier(.2,.8,.2,1)}
  .msg:first-child{border-top:0}
  .badge{display:inline-flex;align-items:center;gap:6px;color:var(--red);font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.1em}
  .badge:before{content:"";width:5px;height:5px;border-radius:50%;background:var(--red)}
  .q{margin:4px 0 8px;color:var(--ink2);font-size:13px}
  .a{font-size:14px;line-height:1.55;color:var(--ink)}
  .a.fade{animation:fade .25s ease}
  .a .lead{font-size:15.5px;font-weight:700;line-height:1.4;margin-bottom:6px}
  .a ul{margin:0 0 6px;padding-left:18px;display:grid;gap:3px}
  .a .tip{margin-top:6px;padding:6px 10px;border-radius:10px;background:var(--soft);color:var(--ink2);font-size:13px}
  .a .tip b{color:var(--red);font-weight:700}
  .a .ln{white-space:pre-wrap}
  .a .code{position:relative;margin:6px 0;border-radius:10px;border:1px solid var(--line);background:var(--code)}
  .a .code .lang{position:absolute;top:5px;right:9px;color:var(--mute);font-size:9.5px;text-transform:uppercase;letter-spacing:.1em}
  .a .code pre{margin:0;padding:10px 12px;overflow-x:auto;white-space:pre;font:12px/1.55 var(--mono);color:var(--ink);scrollbar-width:thin}
  .a.err{color:#ff6b62;font-size:12.5px}
  .caret{display:inline-block;width:7px;height:7px;margin-left:4px;vertical-align:1px;background:var(--red);border-radius:50%;animation:led .8s steps(1) infinite}
  .sk{display:flex;flex-direction:column;gap:8px;padding-top:2px}
  .sk i{height:6px;border-radius:4px;background:var(--soft);animation:led 1.2s ease-in-out infinite}
  .sk i:nth-child(1){width:88%}.sk i:nth-child(2){width:70%;animation-delay:.15s}.sk i:nth-child(3){width:48%;animation-delay:.3s}
  .mf{display:flex;justify-content:flex-end;margin-top:2px}
  .pend{display:flex;align-items:center;gap:10px;margin:0 10px 8px;padding:7px 8px 7px 12px;border-radius:12px;background:var(--soft);font-size:12.5px;animation:drop .2s ease}
  .pend span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--ink2)}
  .bill{display:flex;align-items:center;gap:10px;margin:0 10px 8px;padding:8px 8px 8px 12px;border-radius:12px;border:1px solid rgba(255,59,48,.6);background:rgba(255,59,48,.12);font-size:12.5px;animation:drop .2s ease}
  .bill span{flex:1}
  .chat{display:flex;gap:6px;margin:0 10px 8px;animation:drop .2s ease}
  .chat input{all:unset;flex:1;padding:8px 12px;border-radius:12px;background:var(--field);border:1px solid var(--line);font:13px var(--sans);color:var(--ink)}
  .chat input::placeholder{color:var(--mute)}.chat input:focus{border-color:var(--line2)}
  .foot{display:flex;align-items:center;gap:5px;padding:8px 10px 10px;border-top:1px solid var(--line)}
  .sw{display:flex;align-items:center;gap:7px;cursor:pointer;color:var(--ink2);font-size:11.5px;user-select:none;margin-right:auto}
  .sw input{position:absolute;opacity:0}
  .sw i{width:28px;height:16px;border-radius:99px;border:1px solid var(--line2);position:relative;transition:border-color .15s}
  .sw i:after{content:"";position:absolute;top:3px;left:3px;width:8px;height:8px;border-radius:50%;background:var(--mute);transition:transform .15s,background .15s}
  .sw input:checked+i{border-color:var(--red)}.sw input:checked+i:after{transform:translateX(12px);background:var(--red)}
  .sw input:focus-visible+i{outline:2px solid var(--red);outline-offset:2px}
  .btn{all:unset;display:inline-flex;align-items:center;gap:4px;padding:6px 9px;border-radius:99px;border:1px solid var(--line2);color:var(--ink);font-size:12px;font-weight:600;cursor:pointer;transition:background .12s,border-color .12s,transform .1s;white-space:nowrap}
  .btn:hover{background:var(--soft)}.btn:active{transform:scale(.96)}
  .btn svg{width:14px;height:14px}
  .btn.pri{background:var(--red);border-color:var(--red);color:#fff}.btn.pri:hover{background:#ff5247}
  .btn.end{color:#ff6b62;border-color:rgba(255,59,48,.5)}.btn.end:hover{background:rgba(255,59,48,.12)}
  .btn.on{background:var(--soft);border-color:var(--ink)}
  .panel{display:flex;flex-direction:column;gap:10px;padding:10px 14px 12px;border-top:1px solid var(--line);font-size:12px;color:var(--mute);animation:drop .2s ease}
  .prow{display:flex;align-items:center;justify-content:space-between;gap:12px}
  .mini{display:flex;gap:4px}.mini button{all:unset;cursor:pointer;padding:3px 10px;border-radius:99px;border:1px solid var(--line);font-size:11.5px;color:var(--ink2)}
  .mini button.on{background:var(--ink);border-color:var(--ink);color:rgb(var(--base))}
  input[type=range]{width:150px;accent-color:var(--red)}
  .orb{display:none;width:44px;height:44px;border-radius:50%;place-items:center;cursor:pointer;border:1px solid var(--line2);
    background:rgba(var(--base),calc(var(--op) + .45));backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);box-shadow:0 10px 30px -8px rgba(0,0,0,.6);transition:transform .15s}
  .orb svg.mk{width:20px;height:20px}.orb:hover{transform:scale(1.06)}
  .cue.min .orb{animation:pop .24s cubic-bezier(.2,.8,.2,1)}
  .cue.live .orb{box-shadow:0 0 0 1.5px rgba(255,59,48,.8),0 10px 30px -8px rgba(0,0,0,.6)}
  .cue.min{width:auto}.cue.min .card{display:none}.cue.min .orb{display:grid}
  @media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
  `;

  const HTML = `
  <div class="cue" id="root">
    <div class="orb" id="orb" role="button" tabindex="0" aria-label="Expand Cue">${I.mark}</div>
    <div class="card">
      <div class="head" id="drag">
        <div class="brand">${I.mark}<span>Cue</span></div>
        <span class="led" id="led" aria-hidden="true"></span>
        <span class="timer" id="timer" title="Time in this session">00:00</span>
        <span class="left" id="left" title="Time and credits left"></span>
        <span class="sp"></span>
        <button class="ib" id="gear" title="Display settings" aria-label="Display settings" aria-expanded="false">${I.gear}</button>
        <button class="ib" id="min" title="Minimize" aria-label="Minimize">${I.min}</button>
      </div>
      <div class="status" id="status" role="status">Ready</div>
      <div class="feed" id="feed" aria-live="polite"><p class="empty" id="empty">Questions you are asked show up here. Press Answer to get a suggestion.</p></div>
      <div class="bill" id="bill" role="alert" hidden><span id="btxt"></span><button class="btn pri" id="bbtn">Add credits</button></div>
      <div class="pend" id="pend" hidden><span id="ptxt"></span><button class="btn pri" id="pans">Answer</button></div>
      <div class="chat" id="chat" hidden><input id="ask" type="text" placeholder="Type a question or instruction" aria-label="Type a question or instruction"><button class="btn pri" id="send" aria-label="Send">${I.send}</button></div>
      <div class="foot">
        <label class="sw" title="Answer every detected question automatically. Off saves credits."><input type="checkbox" id="auto"><i></i><span>Auto</span></label>
        <button class="btn pri" id="answer" title="Answer the last question">${I.answer}Answer</button>
        <button class="btn" id="shot" title="Send a screenshot of this tab with the question">${I.shot}Screenshot</button>
        <button class="btn" id="chatBtn" title="Type to Cue" aria-expanded="false">${I.chat}Chat</button>
        <button class="btn end" id="end" title="End the session">${I.end}End</button>
      </div>
      <div class="panel" id="panel" hidden>
        <div class="prow"><span>Theme</span><div class="mini" id="theme"><button data-t="dark">Dark</button><button data-t="light">Light</button></div></div>
        <div class="prow"><span>Opacity</span><input id="op" type="range" min="20" max="60" step="5" value="40" aria-label="Opacity"></div>
        <div class="prow"><span>English</span><div class="mini" id="eng"><button data-e="polished">Polished</button><button data-e="simple">Simple</button></div></div>
      </div>
    </div>
  </div>`;

  // Fonts must live on the document to reach the shadow root. Loading from bytes avoids the page's font CSP.
  let fontsLoaded = false;
  function loadFonts() {
    if (fontsLoaded || !root.chrome || !chrome.runtime || !chrome.runtime.getURL) return;
    fontsLoaded = true;
    [['CueDoto', 'doto.woff2', { weight: '100 900' }], ['CueMono', 'spacemono-400.woff2', { weight: '400' }], ['CueMono', 'spacemono-700.woff2', { weight: '700' }]]
      .forEach(([name, file, desc]) => fetch(chrome.runtime.getURL('assets/fonts/' + file))
        .then(r => r.arrayBuffer()).then(b => new FontFace(name, b, desc).load()).then(f => document.fonts.add(f)).catch(() => {}));
  }

  // Meet and Teams enforce Trusted Types: innerHTML rejects plain strings, and Teams also refuses policies it has
  // not listed. So the overlay never parses HTML. Its markup is our own static templates (tags, quoted attributes,
  // text, <style>, inline SVG), which this small builder turns into DOM nodes with createElement.
  const SVG_NS = 'http://www.w3.org/2000/svg', VOID = /^(input|br|img|hr|meta|link)$/;
  function setHTML(target, html) {
    while (target.firstChild) target.firstChild.remove();
    const stack = [target], re = /<\/([\w-]+)\s*>|<([\w-]+)((?:\s+[\w:-]+(?:="[^"]*")?)*)\s*(\/?)>|([^<]+)/g;
    let m;
    while ((m = re.exec(html))) {
      const top = stack[stack.length - 1];
      if (m[1]) { if (stack.length > 1) stack.pop(); continue; }
      if (m[5] !== undefined) { top.appendChild(document.createTextNode(m[5])); continue; }
      const tag = m[2], svg = tag === 'svg' || (top.namespaceURI === SVG_NS && top !== target);
      const node = svg ? document.createElementNS(SVG_NS, tag) : document.createElement(tag);
      for (const a of m[3].matchAll(/([\w:-]+)(?:="([^"]*)")?/g)) node.setAttribute(a[1], a[2] ?? '');
      top.appendChild(node);
      if (tag === 'style') {                                     // CSS is raw text up to </style>
        const end = html.indexOf('</style>', re.lastIndex);
        node.textContent = html.slice(re.lastIndex, end); re.lastIndex = end + 8; continue;
      }
      if (!m[4] && !VOID.test(tag)) stack.push(node);
    }
  }
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

  function create(h) {
    loadFonts();
    const host = document.createElement('div');
    const sh = host.attachShadow({ mode: 'open' });
    setHTML(sh, `<style>${CSS}</style>${HTML}`);
    document.documentElement.appendChild(host);
    const $ = id => sh.getElementById(id), rootEl = $('root');
    let cur = null; // message being streamed: { raw, a, streaming }

    // ---- drag ----
    let dx = 0, dy = 0, dragging = false, moved = false, px = 0, py = 0, dragRaf = 0;
    const startDrag = e => {
      if (e.target.closest('.ib')) return;
      const r = rootEl.getBoundingClientRect(); dx = e.clientX - r.left; dy = e.clientY - r.top; dragging = true; moved = false;
      e.currentTarget.setPointerCapture(e.pointerId);
    };
    const place = () => {
      dragRaf = 0;
      const r = rootEl.getBoundingClientRect();
      rootEl.style.left = Math.min(innerWidth - Math.min(r.width, 40), Math.max(0, px - dx)) + 'px';
      rootEl.style.top = Math.min(innerHeight - Math.min(r.height, 40), Math.max(0, py - dy)) + 'px';
      rootEl.style.right = 'auto'; rootEl.style.bottom = 'auto';
    };
    const onMove = e => {
      if (!dragging) return;
      if (!moved) { moved = true; rootEl.classList.add('drag'); }
      px = e.clientX; py = e.clientY;
      if (!dragRaf) dragRaf = requestAnimationFrame(place);
    };
    const endDrag = () => { if (dragging && moved) window.dispatchEvent(new CustomEvent('cue:moved')); dragging = false; rootEl.classList.remove('drag'); };
    [$('drag'), $('orb')].forEach(x => { x.addEventListener('pointerdown', startDrag); x.addEventListener('pointermove', onMove); x.addEventListener('pointerup', endDrag); x.addEventListener('pointercancel', endDrag); });
    $('orb').addEventListener('click', () => { if (!moved) rootEl.classList.remove('min'); });
    $('orb').addEventListener('keydown', e => { if (e.key === 'Enter') rootEl.classList.remove('min'); });

    // ---- controls ----
    $('gear').addEventListener('click', () => { const open = $('panel').hidden; $('panel').hidden = !open; $('gear').setAttribute('aria-expanded', open); });
    $('min').addEventListener('click', () => rootEl.classList.add('min'));
    $('op').addEventListener('input', e => { rootEl.style.setProperty('--op', e.target.value / 100); h.onOpacity(+e.target.value); });
    $('theme').addEventListener('click', e => { const t = e.target.dataset && e.target.dataset.t; if (t) h.onTheme(t); });
    $('eng').addEventListener('click', e => { const v = e.target.dataset && e.target.dataset.e; if (v) h.onEnglish(v); });
    $('auto').addEventListener('change', e => h.onAuto(e.target.checked));
    $('answer').addEventListener('click', () => h.onAnswer());
    $('pans').addEventListener('click', () => h.onAnswer());
    $('shot').addEventListener('click', () => h.onScreenshot($('chat').hidden ? '' : $('ask').value.trim()));
    $('end').addEventListener('click', () => h.onStop());
    const toggleChat = open => { $('chat').hidden = !open; $('chatBtn').classList.toggle('on', open); $('chatBtn').setAttribute('aria-expanded', open); if (open) $('ask').focus(); };
    $('chatBtn').addEventListener('click', () => toggleChat($('chat').hidden));
    const send = () => { const v = $('ask').value.trim(); if (v) { h.onManual(v); $('ask').value = ''; } };
    $('send').addEventListener('click', send);
    // Keys typed in the chat box must not reach the meeting page (Meet uses single-key shortcuts).
    $('ask').addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') send(); if (e.key === 'Escape') toggleChat(false); });
    ['keyup', 'keypress'].forEach(ev => $('ask').addEventListener(ev, e => e.stopPropagation()));
    let billFn = null;
    $('bbtn').addEventListener('click', () => billFn && billFn());

    // ---- answer rendering ----
    const feed = $('feed');
    const atBottom = () => feed.scrollHeight - feed.scrollTop - feed.clientHeight < 48;
    let raf = 0;
    const schedule = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; if (cur) render(cur); }); };
    const flush = () => { if (raf) { cancelAnimationFrame(raf); raf = 0; if (cur) render(cur); } };

    // Lays out the answer format: first line (⭐) as the lead, "- " lines as bullets, "Tip:" as a tip, ``` as code.
    function render(m) {
      const stick = atBottom();
      if (!m.shown) { m.shown = true; m.a.classList.add('fade'); }
      m.a.textContent = '';
      let pre = null, ul = null, lead = false, last = null;
      for (const raw of m.raw.split('\n')) {
        const l = raw.replace(/\s+$/, '');
        if (/^\s*```/.test(l)) {
          if (pre) { pre = null; continue; }
          const box = el('div', 'code'), lang = l.replace(/^\s*```/, '').trim();
          if (lang) box.appendChild(el('span', 'lang', lang));
          pre = el('pre'); box.appendChild(pre); m.a.appendChild(box); ul = null; last = pre; continue;
        }
        if (pre) { pre.textContent += (pre.textContent ? '\n' : '') + raw; continue; }
        if (!l.trim()) { ul = null; continue; }
        const b = l.match(/^\s*[-*•]\s+(.*)$/);
        const tip = (b ? b[1] : l).match(/^\s*Tip:\s*(.*)$/i);  // the tip sometimes arrives as a bullet
        if (b && !tip) { if (!ul) { ul = el('ul'); m.a.appendChild(ul); } last = ul.appendChild(el('li', '', b[1])); continue; }
        ul = null;
        if (tip) { const t = el('div', 'tip'); t.append(el('b', '', 'Tip '), document.createTextNode(tip[1])); last = m.a.appendChild(t); continue; }
        if (!lead) { lead = true; last = m.a.appendChild(el('div', 'lead', l.replace(/^\s*⭐\s*/, '⭐ '))); continue; }
        last = m.a.appendChild(el('div', 'ln', l));
      }
      if (m.streaming) (last || m.a).appendChild(el('span', 'caret'));
      if (stick) feed.scrollTop = feed.scrollHeight;
    }

    return {
      setOpacity(p) { p = Math.min(60, Math.max(20, p || 40)); $('op').value = p; rootEl.style.setProperty('--op', p / 100); },
      setTheme(t) { rootEl.classList.toggle('light', t === 'light'); $('theme').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.t === (t === 'light' ? 'light' : 'dark'))); },
      setEnglish(v) { $('eng').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.e === v)); },
      setAuto(v) { $('auto').checked = v; },
      setState(kind, text) {
        ['live', 'paused', 'think'].forEach(k => rootEl.classList.toggle(k, k === kind));
        $('status').textContent = text;
      },
      setTimer(t) { $('timer').textContent = t; },
      setLeft(t, warn) { $('left').textContent = t || ''; $('left').classList.toggle('warn', !!warn); },
      setHeard(speaker, text) { $('status').textContent = (speaker === 'me' ? 'You: ' : 'Heard: ') + text; },
      setPending(p) { $('pend').hidden = !p; $('ptxt').textContent = p ? p.text : ''; },
      notice(text, label, fn) {
        $('bill').hidden = !text; $('btxt').textContent = text || '';
        $('bbtn').hidden = !fn; $('bbtn').textContent = label || ''; billFn = fn || null;
        if (text) rootEl.classList.remove('min', 'hidden');
      },
      newMessage(label, text) {
        flush();
        $('empty').hidden = true; $('pend').hidden = true;
        const m = el('div', 'msg');
        const a = el('div', 'a'), sk = el('div', 'sk'); setHTML(sk, '<i></i><i></i><i></i>'); a.appendChild(sk);
        const mf = el('div', 'mf'), cp = el('button', 'ib'); cp.title = 'Copy answer'; cp.setAttribute('aria-label', 'Copy answer'); setHTML(cp, I.copy);
        const rec = (cur = { raw: '', a, streaming: true });
        cp.addEventListener('click', async () => { const code = rec.raw.match(/```[^\n]*\n([\s\S]*?)(```|$)/); try { await navigator.clipboard.writeText(code ? code[1].trimEnd() : rec.raw); } catch (_) {} setHTML(cp, I.check); setTimeout(() => setHTML(cp, I.copy), 1200); });
        mf.appendChild(cp); m.append(el('span', 'badge', label), el('p', 'q', text), a, mf); feed.appendChild(m);
        feed.scrollTo({ top: feed.scrollHeight, behavior: 'smooth' });
      },
      append(t) { if (cur) { cur.raw += t; schedule(); } },
      done() { if (cur) { cancelAnimationFrame(raf); raf = 0; cur.streaming = false; render(cur); } },
      error(msg) { cancelAnimationFrame(raf); raf = 0; if (cur) { cur.streaming = false; cur.a.className = 'a err'; cur.a.textContent = msg; } },
      clear() { cancelAnimationFrame(raf); raf = 0; cur = null; sh.querySelectorAll('.msg').forEach(n => n.remove()); $('empty').hidden = false; $('pend').hidden = true; },
      // Screenshots must not include the panel itself.
      async withHidden(fn) {
        rootEl.classList.add('snap');
        await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
        try { return await fn(); } finally { rootEl.classList.remove('snap'); }
      },
      toggle() { rootEl.classList.toggle('hidden'); },
      hide() { rootEl.classList.add('hidden'); },
      destroy() { host.remove(); },
    };
  }
  root.CueOverlay = { create };
})(window);
