// Transcription providers. Each has start(onSegment) and stop().
// onSegment({ speaker: 'other' | 'me', text, final })
(function (root) {
  // REAL: browser speech recognition on the microphone. Hears only the user, not the other side of the call.
  const WebSpeechMic = {
    id: 'webspeech-mic', real: true, hears: 'your microphone only',
    supported: () => Boolean(root.SpeechRecognition || root.webkitSpeechRecognition),
    _rec: null, _on: false, lang: 'en-IN', // set from the Call language setting
    start(onSegment) {
      const SR = root.SpeechRecognition || root.webkitSpeechRecognition;
      this._on = true;
      const boot = () => {
        const rec = (this._rec = new SR());
        rec.continuous = true; rec.interimResults = true; rec.lang = this.lang || 'en-IN';
        rec.onresult = e => {
          for (let i = e.resultIndex; i < e.results.length; i++)
            onSegment({ speaker: 'me', text: e.results[i][0].transcript.trim(), final: e.results[i].isFinal });
        };
        rec.onend = () => { if (this._on) try { boot(); } catch (_) {} };
        rec.start();
      };
      boot();
    },
    stop() { this._on = false; try { this._rec && this._rec.stop(); } catch (_) {} },
  };

  // MOCK: scripted interviewer lines so the full pipeline can be demoed without call audio.
  const SCRIPT = [
    [800, 'Thanks for joining. Tell me about a project where you had to deal with'],
    [1600, 'multiple stakeholders who disagreed.'],
    [9000, 'Why do you want this role?'],
    [9000, "Let's say our conversion rate dropped ten percent last week."],
    [3500, 'How would you figure out what happened?'],
  ];
  const MockInterviewer = {
    id: 'mock-interviewer', real: false, hears: 'scripted sample lines (MOCK)',
    supported: () => true, _timers: [],
    start(onSegment) {
      let t = 0;
      SCRIPT.forEach(([gap, text]) => { t += gap; this._timers.push(setTimeout(() => onSegment({ speaker: 'other', text, final: true }), t)); });
    },
    stop() { this._timers.forEach(clearTimeout); this._timers = []; },
  };

  // REAL: the meeting tab's audio (the interviewer). Capture runs in the offscreen document, started from the popup.
  // Transcribed phrases arrive from the background as { type: 'segment' } messages.
  const TabAudio = {
    id: 'tab-audio', real: true, hears: 'meeting audio',
    supported: () => true, _h: null,
    start(onSegment) {
      this._h = m => { if (m.type === 'segment') onSegment(m.seg); };
      chrome.runtime.onMessage.addListener(this._h);
      chrome.runtime.sendMessage({ type: 'capture:pause', paused: false });
    },
    stop() { if (this._h) chrome.runtime.onMessage.removeListener(this._h); chrome.runtime.sendMessage({ type: 'capture:pause', paused: true }); },
    dispose() { this.stop(); chrome.runtime.sendMessage({ type: 'capture:stop' }); },
  };

  // Meeting audio for the interviewer plus your microphone for your own side of the history.
  const TabAndMic = {
    id: 'tab-and-mic', real: true, hears: 'meeting audio and your microphone',
    supported: () => true,
    start(cb) { TabAudio.start(cb); if (WebSpeechMic.supported()) WebSpeechMic.start(cb); },
    stop() { TabAudio.stop(); WebSpeechMic.stop(); },
    dispose() { WebSpeechMic.stop(); TabAudio.dispose(); },
  };

  // (Superseded) notes for the old TODO: Capture the tab with chrome.tabCapture in an
  // offscreen document, stream PCM to a streaming STT provider (Deepgram, AssemblyAI) and emit
  // { speaker: 'other', ... } segments from here. See README, "Plugging in real transcription".
  // Segments pushed by the page itself (the onboarding practice run transcribes the mic and pushes here).
  const External = {
    id: 'external', real: true, hears: 'the practice question', supported: () => true, _cb: null,
    start(cb) { this._cb = cb; }, stop() { this._cb = null; }, push(seg) { if (this._cb) this._cb(seg); },
  };

  root.CueProviders = { WebSpeechMic, MockInterviewer, TabAudio, TabAndMic, External };
})(window);
