// Notch panel: a black teleprompter pinned under the camera at the top of the screen.
// Self-contained: no chrome.* calls, no AI or transcription logic. The host passes in the CSS text and a
// storage adapter, so the same file can run in a Chrome content script or an Electron window.
//
//   const panel = CueNotchPanel.create({ cssText, storage, mode: 'auto', opacity: 40, onClose, onPauseToggle });
//   panel.show(); panel.hide(); panel.pushText(chunk); panel.setMode('auto' | 'manual'); panel.destroy();
//   Extras: clear(), onSpeech(text), setOpacity(20..60), setPaused(bool), toggle(), setHidden(bool)
(function (root) {
  const DEFAULT = { w: 420, h: 140, dx: 0, y: 0, pill: false };
  const MIN_W = 260, MAX_W = 960, MIN_H = 80, MAX_H = 420, KEY = 'notchPanel';
  const memoryStorage = () => { const m = {}; return { get: async k => m[k], set: async (k, v) => { m[k] = v; } }; };
  const words = t => (String(t).toLowerCase().match(/[\p{L}\p{N}']+/gu) || []).filter(w => w.length > 2);
  const el = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };

  // Suggestion text arrives as a stream; turn it into readable teleprompter lines.
  function toLines(text) {
    return text.split('\n')
      .map(l => l.replace(/\s+$/, ''))
      .filter(l => l.trim() && !/^\s*```/.test(l))
      .map(l => l.replace(/^\s*[-*•]\s+/, '• ').replace(/^\s*Tip:\s*/i, 'Tip: '));
  }

  function create(opts = {}) {
    const storage = opts.storage || memoryStorage();
    const container = opts.container || document.documentElement;
    const on = (name, ...a) => typeof opts[name] === 'function' && opts[name](...a);

    // ---- DOM, inside a shadow root ----
    const host = document.createElement('div');
    const shadow = host.attachShadow({ mode: 'open' });
    const style = el('style'); style.textContent = opts.cssText || '';
    const layer = el('div', 'layer');
    const panel = el('div', 'panel off');
    panel.setAttribute('role', 'region'); panel.setAttribute('aria-label', 'Cue suggestion');
    const view = el('div', 'view'), track = el('div', 'track'), glow = el('div', 'glow');
    track.setAttribute('aria-live', 'polite');
    const close = el('button', 'ctl close'); close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label', 'Hide panel');
    const pause = el('button', 'ctl pause'); pause.type = 'button'; pause.setAttribute('aria-label', 'Pause listening');
    const gripL = el('div', 'grip l'), gripR = el('div', 'grip r'), speed = el('div', 'speed');
    view.append(track); panel.append(glow, view, close, pause, gripL, gripR, speed);
    layer.append(panel); shadow.append(style, layer); container.appendChild(host);

    // ---- state ----
    let geo = { ...DEFAULT }, text = '', lines = [], cur = 0, mode = opts.mode === 'manual' ? 'manual' : 'auto';
    let wpm = opts.wpm || 150, userHidden = false, paused = false, timer = null, heard = [], speechSeen = false, destroyed = false;

    // ---- geometry: stored as width, height, horizontal offset from centre, and top ----
    function place() {
      const w = Math.min(MAX_W, Math.max(MIN_W, geo.w)), h = Math.min(MAX_H, Math.max(MIN_H, geo.h));
      const left = Math.round((innerWidth - (geo.pill ? 120 : w)) / 2 + geo.dx);
      panel.style.width = w + 'px'; panel.style.height = h + 'px';
      panel.style.left = Math.min(innerWidth - 60, Math.max(-w + 60, left)) + 'px';
      panel.style.top = Math.max(0, Math.min(innerHeight - 40, geo.y)) + 'px';
      panel.classList.toggle('pill', geo.pill);
      requestAnimationFrame(follow);
    }
    const save = () => storage.set(KEY, { ...geo });
    addEventListener('resize', place);

    // ---- rendering: keep the reading line at the bottom of the view ----
    function render() {
      const next = toLines(text);
      while (track.children.length > next.length) track.lastChild.remove();
      next.forEach((t, i) => {
        let row = track.children[i];
        if (!row) { row = el('div', 'ln'); track.appendChild(row); }
        if (row.textContent !== t) row.textContent = t;
      });
      lines = next;
      cur = Math.min(cur, Math.max(0, lines.length - 1));
      mark(); follow();
    }
    function mark() {
      [...track.children].forEach((row, i) => { row.classList.toggle('now', i === cur); row.classList.toggle('past', i < cur); row.classList.toggle('next', i > cur); });
    }
    function follow() {
      const row = track.children[cur];
      if (!row) return;
      const y = view.clientHeight - (row.offsetTop + row.offsetHeight);
      track.style.transform = `translateY(${Math.round(y)}px)`;
    }
    function go(i) {
      const n = Math.max(0, Math.min(lines.length - 1, i));
      if (n === cur) return;
      cur = n; heard = []; mark(); follow(); schedule();
    }

    // ---- auto mode: advance when the user has said the line, or at reading pace without speech ----
    function schedule() {
      clearTimeout(timer);
      if (mode !== 'auto' || paused || cur >= lines.length - 1) return;
      const n = Math.max(3, words(lines[cur]).length);
      const ms = (n / wpm) * 60_000 + 1200;
      timer = setTimeout(() => go(cur + 1), speechSeen ? ms * 2.5 : ms);   // speech leads; time is the fallback
    }
    function onSpeech(said) {
      if (mode !== 'auto' || paused || !lines.length) return;
      speechSeen = true;
      heard = heard.concat(words(said)).slice(-40);
      const want = words(lines[cur]);
      if (!want.length) return go(cur + 1);
      const got = want.filter(w => heard.includes(w)).length;
      const tail = want.slice(-2).every(w => heard.includes(w));
      if (got / want.length >= 0.6 || (tail && got >= 2)) go(cur + 1);
    }

    // ---- show / hide ----
    function visible() { return !userHidden && lines.length > 0; }
    function sync() { panel.classList.toggle('off', !visible()); if (visible()) requestAnimationFrame(follow); }

    // ---- dragging, resizing, collapse ----
    let drag = null;
    panel.addEventListener('pointerdown', e => {
      if (e.button !== 0 || e.target.closest('.ctl')) return;
      const kind = e.target === gripL ? 'l' : e.target === gripR ? 'r' : 'move';
      drag = { kind, x: e.clientX, y: e.clientY, geo: { ...geo }, moved: false };
      panel.setPointerCapture(e.pointerId);
    });
    panel.addEventListener('pointermove', e => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 4) return;
      drag.moved = true;
      if (drag.kind === 'move') {
        panel.classList.add('dragging');
        geo.dx = drag.geo.dx + dx;
        geo.y = drag.geo.y + dy < 16 ? 0 : drag.geo.y + dy;                    // snaps back to the top edge
      } else {
        panel.classList.add('resizing');
        const sign = drag.kind === 'r' ? 1 : -1;
        const w = Math.min(MAX_W, Math.max(MIN_W, drag.geo.w + sign * dx));
        geo.w = w; geo.dx = drag.geo.dx + sign * (w - drag.geo.w) / 2;          // the dragged edge moves; the other stays put
        geo.h = Math.min(MAX_H, Math.max(MIN_H, drag.geo.h + dy));
      }
      place();
    });
    const endDrag = () => {
      if (!drag) return;
      const moved = drag.moved, kind = drag.kind; drag = null;
      panel.classList.remove('dragging', 'resizing');
      if (moved) { save(); on(kind === 'move' ? 'onMoved' : 'onResized', { ...geo }); }
    };
    panel.addEventListener('pointerup', endDrag); panel.addEventListener('pointercancel', endDrag);
    panel.addEventListener('dblclick', e => {
      if (e.target.closest('.ctl') || e.target.classList.contains('grip')) return;
      geo.pill = !geo.pill; place(); save(); on('onCollapse', geo.pill);
    });
    close.addEventListener('click', () => { api.setHidden(true); on('onClose'); });
    pause.addEventListener('click', () => on('onPauseToggle'));

    // ---- manual keys: Up/K back, Down/J forward, +/- speed. Never while typing in the page. ----
    let speedTimer = null;
    function onKey(e) {
      if (!visible() || geo.pill || e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.composedPath()[0];
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      const k = e.key;
      if (k === '+' || k === '=' || k === '-' || k === '_') {
        wpm = Math.max(60, Math.min(300, wpm + (k === '+' || k === '=' ? 15 : -15)));
        speed.textContent = `${wpm} wpm`; speed.classList.add('on'); clearTimeout(speedTimer); speedTimer = setTimeout(() => speed.classList.remove('on'), 1200);
        schedule(); e.preventDefault(); return;
      }
      if (mode !== 'manual') return;
      if (k === 'ArrowDown' || k === 'j' || k === 'J') { go(cur + 1); e.preventDefault(); e.stopPropagation(); }
      if (k === 'ArrowUp' || k === 'k' || k === 'K') { go(cur - 1); e.preventDefault(); e.stopPropagation(); }
    }
    addEventListener('keydown', onKey, true);

    const api = {
      show() { userHidden = false; sync(); },
      hide() { userHidden = true; sync(); },
      setHidden(h) { userHidden = Boolean(h); sync(); },
      toggle() { userHidden = !userHidden; sync(); return !userHidden; },
      // Streams a suggestion in. The first text after clear() expands the panel.
      pushText(chunk) {
        if (destroyed || !chunk) return;
        const was = lines.length;
        text += chunk; render();
        if (!was && lines.length) { sync(); schedule(); }
        else if (cur === lines.length - 1 || was !== lines.length) schedule();
      },
      // Ends the current suggestion; the panel hides until the next one arrives.
      clear() { clearTimeout(timer); text = ''; lines = []; cur = 0; heard = []; track.textContent = ''; sync(); },
      setMode(m) { mode = m === 'manual' ? 'manual' : 'auto'; schedule(); },
      onSpeech,
      setOpacity(p) { const v = Math.min(60, Math.max(20, Number(p) || 40)); panel.style.setProperty('--text-alpha', (0.4 + (v - 20) / 40 * 0.6).toFixed(2)); },
      setPaused(p) { paused = Boolean(p); panel.classList.toggle('paused', paused); pause.setAttribute('aria-label', paused ? 'Resume listening' : 'Pause listening'); if (paused) clearTimeout(timer); else schedule(); },
      isVisible: visible,
      destroy() { destroyed = true; clearTimeout(timer); removeEventListener('resize', place); removeEventListener('keydown', onKey, true); host.remove(); },
    };

    api.setOpacity(opts.opacity ?? 40);
    Promise.resolve(storage.get(KEY)).then(g => { if (g && !destroyed) geo = { ...DEFAULT, ...g }; place(); }).catch(place);
    place();
    return api;
  }

  root.CueNotchPanel = { create };
  if (typeof module !== 'undefined') module.exports = root.CueNotchPanel;
})(typeof window !== 'undefined' ? window : globalThis);
