// Chrome glue for the notch panel. It loads the panel's CSS from the extension, stores its size and position in
// chrome.storage.local, and exposes the same methods as the classic overlay (content/overlay.js), so the session
// code in content.js can drive either one. The panel module itself (notch-panel.js) stays free of chrome.* calls.
(function (root) {
  let cssText = null;
  async function loadCss() {
    if (cssText !== null) return cssText;
    try { cssText = await (await fetch(chrome.runtime.getURL('content/notch-panel.css'))).text(); }
    catch (_) { cssText = ''; }
    return cssText;
  }
  const storage = {
    get: k => new Promise(r => chrome.storage.local.get(k, v => r(v[k]))),
    set: (k, v) => new Promise(r => chrome.storage.local.set({ [k]: v }, r)),
  };

  // h: the session handlers from content.js (onStop, onPause, onOpacity ...); settings: the saved settings.
  async function create(h, settings = {}) {
    const panel = root.CueNotchPanel.create({
      cssText: await loadCss(), storage,
      mode: settings.notchMode || 'auto', opacity: settings.opacity || 40,
      onClose: () => {},                                   // hides only; Alt+Shift+C brings it back, the popup ends the session
      onPauseToggle: () => h.onPause && h.onPause(),
      onMoved: () => window.dispatchEvent(new CustomEvent('cue:moved')),
      onCollapse: pill => window.dispatchEvent(new CustomEvent('cue:collapsed', { detail: { pill } })),
    });
    let notice = '', state = '', said = '', clock = '', left = '';
    // Until an answer arrives the notch shows what Cue is doing, then the latest words it heard, so it never looks dead.
    const idle = () => panel.setIdle(state === 'think' ? 'Thinking…' : said ? said : state === 'paused' ? 'Paused. Press the dot to resume.' : 'Listening. Answers appear here when you are asked a question.');
    const meta = () => panel.setMeta([clock, left].filter(Boolean).join(' · '));
    idle(); panel.setStatus('live', 'Starting');
    return {
      notch: true,
      // Suggestions
      newMessage() { said = ''; panel.clear(); },
      append(t) { panel.pushText(t); },
      done() {},
      error(msg) { panel.clear(); panel.pushText('Could not answer: ' + msg); },
      clear() { panel.clear(); },
      // Speech from the user's mic moves the teleprompter in auto mode.
      onSpeech: text => panel.onSpeech(text),
      // Status goes on the top line; until an answer arrives it also fills the reading line.
      setState(kind, text) {
        state = kind; panel.setPaused(kind === 'paused');
        panel.setStatus(kind, kind === 'think' ? 'Thinking' : kind === 'paused' ? (text || 'Paused') : 'Listening');
        idle();
      },
      setHeard(speaker, text) { said = (speaker === 'me' ? 'You: ' : 'Heard: ') + text; idle(); },
      notice(text) { if (!text) { if (notice) { panel.clear(); notice = ''; } return; } notice = text; panel.clear(); panel.pushText(text); panel.show(); },
      setOpacity(p) { panel.setOpacity(p); },
      setMode(m) { panel.setMode(m); },
      setTimer(t) { clock = t; meta(); },
      setLeft(t) { left = t || ''; meta(); },
      setPending() {}, setTheme() {}, setEnglish() {}, setAuto() {},
      async withHidden(fn) { panel.hide(); await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); try { return await fn(); } finally { panel.show(); } },
      toggle() { return panel.toggle(); },
      hide() { panel.hide(); },
      destroy() { panel.destroy(); },
    };
  }

  root.CueNotchUI = { create };
})(window);
