// Chrome glue for the notch panel. It loads the panel's CSS from the extension, stores its size and position in
// chrome.storage.local, and exposes the same methods as the classic overlay (content/overlay.js), so the session
// code in content.js can drive either one. The panel module itself (notch-panel.js) stays free of chrome.* calls.
(function (root) {
  let cssText = null;
  async function loadCss() {
    if (cssText !== null) return cssText;
    try { cssText = await (await fetch(chrome.runtime.getURL('content/notch-panel.css'))).text(); }
    catch (_) { cssText = ''; }
    return cssText;
  }
  const storage = {
    get: k => new Promise(r => chrome.storage.local.get(k, v => r(v[k]))),
    set: (k, v) => new Promise(r => chrome.storage.local.set({ [k]: v }, r)),
  };

  // h: the session handlers from content.js (onStop, onPause, onOpacity ...); settings: the saved settings.
  async function create(h, settings = {}) {
    const panel = root.CueNotchPanel.create({
      cssText: await loadCss(), storage,
      mode: settings.notchMode || 'auto', opacity: settings.opacity || 40,
      onClose: () => {},                                   // hides only; Alt+Shift+C brings it back, the popup ends the session
      onPauseToggle: () => h.onPause && h.onPause(),
      onMoved: () => window.dispatchEvent(new CustomEvent('cue:moved')),
      onCollapse: pill => window.dispatchEvent(new CustomEvent('cue:collapsed', { detail: { pill } })),
    });
    let notice = '';
    return {
      notch: true,
      // Suggestions
      newMessage() { panel.clear(); },
      append(t) { panel.pushText(t); },
      done() {},
      error(msg) { panel.clear(); panel.pushText('Could not answer: ' + msg); },
      clear() { panel.clear(); },
      // Speech from the user's mic moves the teleprompter in auto mode.
      onSpeech: text => panel.onSpeech(text),
      // Status the notch has no room for is left out; pause is shown on the pause dot.
      setState(kind) { panel.setPaused(kind === 'paused'); },
      notice(text) { if (!text) { if (notice) { panel.clear(); notice = ''; } return; } notice = text; panel.clear(); panel.pushText(text); panel.show(); },
      setOpacity(p) { panel.setOpacity(p); },
      setMode(m) { panel.setMode(m); },
      setTimer() {}, setLeft() {}, setHeard() {}, setPending() {}, setTheme() {}, setEnglish() {}, setAuto() {},
      async withHidden(fn) { panel.hide(); await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); try { return await fn(); } finally { panel.show(); } },
      toggle() { return panel.toggle(); },
      hide() { panel.hide(); },
      destroy() { panel.destroy(); },
    };
  }

  root.CueNotchUI = { create };
})(window);
