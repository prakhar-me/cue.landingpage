(function () {
  if (window.__cueLoaded) return; window.__cueLoaded = true;
  const D = window.CueDetector, P = window.CueProviders, SS = window.CueSessions, DOCS = window.CueDocs;
  const S = { on: false, paused: false, mode: 'interview', auto: false, ui: null, provider: null, buf: [], timer: null,
    history: [], log: null, last: null, pending: null, port: null, startedAt: 0, tick: null, source: '', rec: null,
    session: null, msLeft: 0, leftAt: 0, beat: null, beating: false, out: false, creditMs: 6 * 60_000, free: false };
  const MAX_HISTORY = 30, MAX_LOG = 1500;
  const get = k => new Promise(r => chrome.storage.local.get(k, r));
  // Settings writes are read-modify-write, so they run one at a time; otherwise two quick changes overwrite each other.
  let settingsQ = Promise.resolve();
  const setSetting = patch => (settingsQ = settingsQ.then(async () => { const { settings = {} } = await get('settings'); await chrome.storage.local.set({ settings: { ...settings, ...patch } }); }));
  const api = (path, body) => chrome.runtime.sendMessage({ type: 'api', path, body });
  const WARN_MS = 5 * 60_000, BEAT_MS = 30_000;
  const fmtLeft = ms => { const s = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}:${String(s % 60).padStart(2, '0')}`; };
  const localLeft = () => (S.paused || S.out ? S.msLeft : S.msLeft - (Date.now() - S.leftAt));
  // The detector's meeting patterns apply to regular calls.
  const detectMode = () => (S.mode === 'call' ? 'meeting' : 'interview');

  // ---- Credits: the server meters time; the overlay shows a local countdown between heartbeats ----
  async function beat() {
    if (!S.on || !S.session || S.beating) return;
    S.beating = true;
    try {
      const r = await api('/api/session/beat', { sessionId: S.session, paused: S.paused || S.out });
      if (r && r.ok) {
        S.msLeft = r.data.msLeft; S.leftAt = Date.now();
        if (r.data.status === 'exhausted') outOfCredits();
        else if (r.data.status !== 'live') outOfCredits(r.data.timeUp ? 'Your free time for this session is up.' : 'This session ended on the server. Start a new one from the Cue popup.', false);
      } else if (r && (r.code === 'session' || r.code === 'auth')) outOfCredits(r.error, false);
    } catch (_) {} // offline: try again on the next beat
    S.beating = false;
  }

  function outOfCredits(msg, offerTopUp = true) {
    if (!S.on || S.out) return;
    S.out = true; S.msLeft = 0;
    S.provider.stop(); clearTimeout(S.timer);
    S.ui.setState('paused', offerTopUp ? 'Out of credits' : 'Session ended');
    S.ui.setLeft('0:00', true);
    S.ui.notice(msg || 'Your credits ran out. Add credits, then start a new session from the Cue popup.', 'Add credits',
      offerTopUp ? () => chrome.runtime.sendMessage({ type: 'open-billing' }) : null);
  }

  function showLeft() {
    if (!S.session) return S.ui.setLeft('');
    const ms = localLeft(), credits = Math.max(0, Math.floor(ms / S.creditMs));
    S.ui.setLeft(S.free ? `${fmtLeft(ms)} free` : `${fmtLeft(ms)} · ${credits} cr`, ms < WARN_MS);
    if (ms <= 0 && !S.out) beat();
  }

  function pickProvider(source) {
    if (source === 'mock') return P.MockInterviewer;
    if (source === 'tabmic') return P.TabAndMic;
    if (source === 'external') return P.External;
    return P.TabAudio;
  }
  const listening = () => (S.provider.real ? 'Listening' : 'Listening (sample interviewer)');
  const fmt = ms => { const s = Math.floor(ms / 1000); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

  // opts: { recordId, sessionId, msLeft, source, tabId, creditMinutes, free, auto }  (mode comes from the session record)
  async function start(opts) {
    if (S.on) return;
    const { settings = {} } = await get('settings');
    S.rec = opts.recordId ? await SS.get(opts.recordId) : null;
    S.mode = (S.rec && S.rec.mode) || opts.mode || 'interview';
    if (S.mode === 'meeting') S.mode = 'call';
    S.source = opts.source;
    S.auto = opts.auto ?? settings.autoAnswer === true;   // off by default: answers only when asked, to save credits
    S.log = (S.rec ? S.rec.saveTranscript : settings.saveTranscripts) ? [] : null;
    S.lang = (S.rec && S.rec.lang) || settings.lang || 'auto';
    S.english = settings.english || 'polished';
    S.creditMs = (opts.creditMinutes || 6) * 60_000; S.free = Boolean(opts.free);
    P.WebSpeechMic.lang = { en: 'en-IN', hi: 'hi-IN' }[S.lang] || 'en-IN';
    // Display: the notch teleprompter at the top (default) or the classic panel with buttons.
    const notch = (settings.display || 'notch') === 'notch' && window.CueNotchUI;
    // The notch has no Answer button, so every detected question is answered there.
    if (notch) S.auto = true;
    const handlers = {
      onPause: () => setPaused(!S.paused),
      onOpacity: p => setSetting({ opacity: p }),
      onTheme: t => { S.ui.setTheme(t); setSetting({ theme: t }); },
      onEnglish: v => { S.english = v; S.ui.setEnglish(v); setSetting({ english: v }); },
      onAuto: v => { S.auto = v; setSetting({ autoAnswer: v }); },
      onAnswer: answerNow,
      onScreenshot: screenshot,
      onManual: t => ask(t, D.classify(t, detectMode()).kind === 'code' ? 'code' : 'question', 'You asked'),
      onStop: stop,
    };
    S.ui = notch ? await window.CueNotchUI.create(handlers, settings) : window.CueOverlay.create(handlers);
    S.ui.setOpacity(settings.opacity || 40); S.ui.setTheme(settings.theme || 'dark'); S.ui.setAuto(S.auto); S.ui.setEnglish(S.english);
    S.provider = pickProvider(opts.source);
    S.on = true; S.paused = false; S.out = false; S.startedAt = Date.now();
    S.session = opts.sessionId || null; S.msLeft = opts.msLeft || 0; S.leftAt = Date.now();
    S.tick = setInterval(() => { S.ui.setTimer(fmt(Date.now() - S.startedAt)); showLeft(); }, 1000);
    S.beat = setInterval(beat, BEAT_MS);
    showLeft();
    S.provider.start(onSegment);
    S.ui.setState('live', S.auto ? listening() : listening() + '. Press Answer when you want a suggestion.');
    if (S.rec) SS.update(S.rec.id, { status: 'live', startedAt: S.startedAt, serverSessionId: S.session, tabId: opts.tabId ?? null, armedAt: null });
  }

  function setPaused(p) {
    if (!S.on || S.out) return;
    S.msLeft = localLeft(); S.leftAt = Date.now();
    S.paused = p; beat();
    if (p) { S.provider.stop(); clearTimeout(S.timer); S.ui.setState('paused', 'Paused'); }
    else { S.provider.start(onSegment); S.ui.setState('live', listening()); }
  }

  async function stop() {
    if (!S.on) return;
    S.provider.dispose ? S.provider.dispose() : S.provider.stop();
    clearTimeout(S.timer); clearInterval(S.tick); clearInterval(S.beat);
    if (S.port) { try { S.port.disconnect(); } catch (_) {} S.port = null; }
    let used = null;
    if (S.session) { try { const r = await api('/api/session/end', { sessionId: S.session }); if (r && r.ok) used = r.data.usedCredits; } catch (_) {} }
    const rec = S.rec, transcript = S.log && S.log.length ? S.log : null, endedAt = Date.now(), startedAt = S.startedAt;
    S.ui.destroy(); S.on = false; S.buf = []; S.history = []; S.log = null; S.last = null; S.pending = null; S.session = null; S.out = false; S.rec = null;
    if (!rec) return;
    await SS.update(rec.id, { status: 'ended', endedAt, durationMs: endedAt - startedAt, creditsUsed: used, transcript, tabId: null });
    // AI notes from the saved transcript, written in the background after the call.
    if (transcript) {
      try {
        const r = await api('/api/notes', { transcript, mode: rec.mode, title: rec.title });
        if (r && r.ok) await SS.update(rec.id, { notes: r.data.notes });
      } catch (_) {}
    }
  }

  function onSegment(seg) {
    if (S.capErr && seg.speaker === 'other') { S.capErr = false; S.ui.notice(''); }
    if (seg.text && S.ui) { S.ui.setHeard(seg.speaker, seg.text); window.dispatchEvent(new CustomEvent('cue:heard', { detail: seg })); }
    // The user's own speech (Call + mic) moves the notch teleprompter in auto mode.
    if (seg.text && seg.speaker === 'me' && S.ui && S.ui.onSpeech) S.ui.onSpeech(seg.text);
    if (!seg.final || !seg.text) return;
    S.history.push({ speaker: seg.speaker, text: seg.text }); if (S.history.length > MAX_HISTORY) S.history.shift();
    if (S.log && S.log.length < MAX_LOG) S.log.push({ speaker: seg.speaker, text: seg.text, at: Date.now() - S.startedAt });
    if (seg.speaker !== 'other') return;
    S.buf.push(seg.text);
    clearTimeout(S.timer);
    S.timer = setTimeout(flush, D.settleDelay(S.buf.join(' ')));
  }

  // A finished question: answer it now (Auto on), or show it with an Answer button (Auto off).
  function flush() {
    const text = S.buf.join(' ').trim(); S.buf = [];
    const c = D.classify(text, detectMode());
    if (!c.isQuestion) return;
    if (S.auto) ask(text, c.kind, c.label);
    else { S.pending = { text, kind: c.kind, label: c.label }; S.ui.setPending(S.pending); }
  }

  // What the other side most recently asked: the pending question, or their last few lines.
  function lastQuestion() {
    if (S.pending) return S.pending;
    const t = [];
    for (let i = S.history.length - 1; i >= 0 && S.history[i].speaker === 'other' && t.length < 4; i--) t.unshift(S.history[i].text);
    const text = (S.buf.join(' ') + ' ' + t.join(' ')).trim();
    if (!text) return null;
    const c = D.classify(text, detectMode());
    return { text, kind: c.kind || 'question', label: c.label || 'Question' };
  }

  function answerNow() {
    const q = lastQuestion() || (S.last && { text: S.last.text, kind: S.last.kind, label: S.last.label });
    if (!q) return S.ui.setState('live', 'Nothing to answer yet. Wait for a question, or use Chat.');
    S.buf = []; clearTimeout(S.timer);
    ask(q.text, q.kind, q.label);
  }

  // Captures the tab (without the panel). Without typed text, the question is whatever is on screen;
  // the recent conversation still goes along as context.
  async function screenshot(typed) {
    if (!S.on) return;
    S.ui.setState('think', 'Taking a screenshot');
    const r = await S.ui.withHidden(() => chrome.runtime.sendMessage({ type: 'screenshot' }).catch(e => ({ ok: false, error: e.message })));
    if (!r || !r.ok) { S.ui.setState('live', listening()); return S.ui.notice('Could not take a screenshot: ' + ((r && r.error) || 'unknown error')); }
    S.buf = []; clearTimeout(S.timer);
    const kind = typed && D.classify(typed, detectMode()).kind === 'code' ? 'code' : null;
    ask(typed || 'Answer the question shown on my screen.', kind, 'Screenshot', r.image);
  }

  // Context sent with each question: the session's details and instructions, the resume in interviews,
  // and only the parts of other documents that match the question.
  async function buildContext(question) {
    const [{ context = {} }, docs] = await Promise.all([get('context'), SS.docs()]);
    const r = S.rec || {}, interview = S.mode !== 'call';
    const query = [question, ...S.history.slice(-4).map(h => h.text)].join(' ');
    const resume = docs.filter(d => d.kind === 'resume').map(d => d.text).join('\n\n') || context.resume || '';
    return {
      title: r.title, company: r.company || context.company, role: r.role || context.role, instructions: r.instructions || context.jd || '',
      resume: interview ? resume : '', projects: interview ? context.projects || [] : [],
      docs: DOCS.relevant(docs.filter(d => d.kind !== 'resume'), query),
      name: context.name, currentRole: context.currentRole, years: context.years, skills: context.skills,
    };
  }

  async function ask(text, kind, label, image = null) {
    if (S.out) return S.ui.notice('No credits left for this session. Add credits, then start a new session.', 'Add credits', () => chrome.runtime.sendMessage({ type: 'open-billing' }));
    if (S.paused) return S.ui.setState('paused', 'Resume Cue to get answers');
    S.pending = null; S.ui.setPending(null);
    S.last = { text, kind, label };
    S.ui.newMessage(label || 'Question', text);
    S.ui.setState('think', image ? 'Reading the screenshot' : 'Thinking');
    const context = await buildContext(text);
    if (S.port) { try { S.port.disconnect(); } catch (_) {} }
    const port = (S.port = chrome.runtime.connect({ name: 'suggest' }));
    port.onMessage.addListener(m => {
      if (m.t) { S.ui.setState('live', listening()); S.ui.append(m.t); }
      if (m.done) { S.ui.done(); window.dispatchEvent(new CustomEvent('cue:answer', { detail: { question: text } })); }
      if (m.error) {
        S.ui.error(m.error);
        if (m.code === 'credits') outOfCredits(); else if (m.code === 'session') outOfCredits(m.error, false); else S.ui.setState('live', listening());
      }
    });
    port.postMessage({ session: S.session, question: text, kind, mode: S.mode, lang: S.lang, english: S.english, context, history: S.history.slice(-8), ...(image ? { image } : {}) });
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg.type === 'start') {
      // Reply with the real failure so the popup does not report it as "Cue is not active".
      start(msg).then(() => reply({ ok: true }), e => { console.error('[Cue] start failed', e); try { S.ui && S.ui.destroy(); } catch (_) {} S.on = false; reply({ ok: false, error: e && e.message || String(e) }); });
      return true;
    }
    if (msg.type === 'stop') { stop().then(() => reply({ ok: true })); return true; }
    if (msg.type === 'status') reply({ on: S.on, paused: S.paused, recordId: S.rec && S.rec.id });
    else if (msg.type === 'capture-error' && S.ui) {
      // Shown as a banner: ui.error() only reaches an answer that is streaming, so capture errors were invisible.
      if (msg.code === 'credits') outOfCredits(); else if (msg.code === 'session') outOfCredits(msg.error, false);
      else { S.capErr = true; S.ui.notice('Not hearing the call: ' + msg.error); }
    }
    else if (msg.type === 'cmd' && S.on) {
      if (msg.name === 'toggle-overlay') { S.ui.toggle(); window.dispatchEvent(new CustomEvent('cue:toggled')); }
      if (msg.name === 'hide-overlay') S.ui.hide();
      if (msg.name === 'toggle-pause') setPaused(!S.paused);
    }
  });

  // The welcome page runs the free demo in-page with the same session code, so it calls this directly.
  window.CueSession = { start, stop, state: () => ({ on: S.on, out: S.out }) };
})();
