// Relays backend calls so page CORS rules never apply and no API key lives in the extension.
importScripts('../shared/config.js', '../shared/client.js');
const C = self.CueClient;

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'suggest') return;
  const ctl = new AbortController();
  port.onDisconnect.addListener(() => ctl.abort());
  port.onMessage.addListener(async ({ session, ...body }) => {
    try {
      const res = await C.authFetch('/api/suggest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctl.signal }, session);
      if (!res.ok) { const j = await res.json().catch(() => ({})); return port.postMessage({ error: j.error || `Backend returned ${res.status}`, code: j.code }); }
      const reader = res.body.getReader(), dec = new TextDecoder(); let buf = '';
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let i; while ((i = buf.indexOf('\n\n')) >= 0) {
          const line = buf.slice(0, i).replace(/^data: /, ''); buf = buf.slice(i + 2);
          if (line === '[DONE]') return port.postMessage({ done: true });
          try { port.postMessage(JSON.parse(line)); } catch (_) {}
        }
      }
    } catch (e) { if (e.name !== 'AbortError') port.postMessage({ error: e.message, code: e.code }); }
  });
});

chrome.commands.onCommand.addListener(async name => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) chrome.tabs.sendMessage(tab.id, { type: 'cmd', name }).catch(() => {});
  chrome.runtime.sendMessage({ type: 'cmd', name }).catch(() => {}); // Cue's own pages, such as the setup guide
});

// ---- Meeting audio capture ----
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({ url: 'offscreen/offscreen.html', reasons: ['USER_MEDIA'], justification: 'Capture and transcribe meeting tab audio during a session the user started.' });
}

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (m.target === 'offscreen') return;
  // Generic JSON call for content scripts, popup and options: { type: 'api', path, method, body }
  if (m.type === 'api') {
    C.api(m.path, { method: m.method, body: m.body }).then(data => reply({ ok: true, data }), e => reply({ ok: false, error: e.message, code: e.code }));
    return true;
  }
  // The overlay's Screenshot button. activeTab (granted when the user starts Cue from the toolbar) allows this.
  if (m.type === 'screenshot') {
    const windowId = sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
    chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 70 })
      .then(image => reply({ ok: true, image }), e => reply({ ok: false, error: e.message }));
    return true;
  }
  if (m.type === 'open-billing') { chrome.tabs.create({ url: chrome.runtime.getURL('options/options.html#billing') }); return; }
  if (m.type === 'capture:start') {
    (async () => {
      try {
        const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: m.tabId });
        await ensureOffscreen();
        const [backend, token, { settings = {} }] = await Promise.all([C.backend(), C.token(), chrome.storage.local.get('settings')]);
        const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'init', streamId, tabId: m.tabId, session: m.session, backend, token, lang: settings.lang || 'auto' });
        reply(r && r.ok ? { ok: true } : { ok: false, error: (r && r.error) || 'Could not start audio capture.' });
      } catch (e) { reply({ ok: false, error: e.message }); }
    })();
    return true;
  }
  if (m.type === 'capture:pause') chrome.runtime.sendMessage({ target: 'offscreen', type: 'pause', paused: m.paused }).catch(() => {});
  if (m.type === 'capture:stop') chrome.offscreen.closeDocument().catch(() => {});
  if (m.type === 'transcript') chrome.tabs.sendMessage(m.tabId, { type: 'segment', seg: { speaker: 'other', text: m.text, final: true } }).catch(() => {});
  if (m.type === 'capture:error') chrome.tabs.sendMessage(m.tabId, { type: 'capture-error', error: m.error, code: m.code }).catch(() => {});
});

chrome.runtime.onInstalled.addListener(({ reason }) => {
  // The setup guide opens on install only. Updates get a small "NEW" badge; the popup says what changed.
  if (reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('welcome/welcome.html') });
  if (reason === 'update') {
    chrome.storage.local.set({ whatsNew: chrome.runtime.getManifest().version });
    chrome.action.setBadgeText({ text: 'NEW' }); chrome.action.setBadgeBackgroundColor({ color: '#ff3b30' });
  }
});
