// Setup guide, opened once on install: welcome, pin, microphone, optional context, a free practice run,
// the three mid-call controls, the price, and a checklist returning users can finish later.
const $ = id => document.getElementById(id);
const C = self.CueClient, SS = self.CueSessions;
const STEPS = ['welcome', 'pin', 'mic', 'context', 'practice', 'controls', 'credits', 'done'];
const get = k => new Promise(r => chrome.storage.local.get(k, r));
let O = {};                      // onboarding progress: { pinned, mic, context, practice, toggle, drag, opacity, done }
let step = 'welcome', acct = null;

async function mark(patch) { O = { ...O, ...patch }; await chrome.storage.local.set({ onboarding: O }); paintChecks(); }

function show(name) {
  if (step === 'controls' && name !== 'controls') endPanel();
  if (step === 'pin' && name !== 'pin') clearInterval(pinTimer);
  step = name;
  document.querySelectorAll('section[data-step]').forEach(s => (s.hidden = s.dataset.step !== name));
  const i = STEPS.indexOf(name);
  $('dots').querySelectorAll('li').forEach((d, j) => { d.classList.toggle('on', j === i); d.classList.toggle('done', j < i); });
  history.replaceState(null, '', '#' + name);
  window.scrollTo(0, 0);
  ({ pin: startPin, mic: checkMic, context: loadContext, practice: preparePractice, controls: startControls, credits: renderCredits, done: finish })[name]?.();
}
const next = () => show(STEPS[Math.min(STEPS.length - 1, STEPS.indexOf(step) + 1)]);

// ---------- 1. Welcome clip: the panel types an answer, on a loop ----------
const CLIP = ['⭐ Product manager who ships checkout fixes that move numbers.', '- 3 years at Swiggy owning order tracking', '- Added live ETA, support tickets fell 18%', '- Now want to do the same for merchants', 'Tip: lead with the 18% result'];
async function playClip() {
  const box = $('clipAnswer'), reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  for (;;) {
    box.textContent = '';
    for (const line of CLIP) {
      const el = document.createElement('div'); if (line.startsWith('⭐')) el.className = 'lead'; box.appendChild(el);
      if (reduce) { el.textContent = line; continue; }
      for (const ch of line) { el.textContent += ch; await new Promise(r => setTimeout(r, 22)); }
      await new Promise(r => setTimeout(r, 160));
    }
    await new Promise(r => setTimeout(r, reduce ? 60000 : 3200));
  }
}

// ---------- 2. Pin: detected with chrome.action.getUserSettings() ----------
let pinTimer = null;
function startPin() {
  clearInterval(pinTimer);
  const check = async () => {
    let on = false; try { on = (await chrome.action.getUserSettings()).isOnToolbar; } catch (_) {}
    if (on) { clearInterval(pinTimer); $('pinStatus').textContent = 'Pinned. Nice.'; await mark({ pinned: true }); setTimeout(() => step === 'pin' && next(), 900); }
  };
  check(); pinTimer = setInterval(check, 1000);
}

// ---------- 3. Microphone ----------
async function micState() { try { return (await navigator.permissions.query({ name: 'microphone' })).state; } catch (_) { return 'prompt'; } }
async function checkMic() {
  $('micDenied').hidden = true; $('micErr').textContent = '';
  const st = await micState();
  if (st === 'granted') { $('micAllow').textContent = 'Microphone allowed · Continue'; await mark({ mic: true }); }
  if (st === 'denied') $('micDenied').hidden = false;
}
async function askMic() {
  $('micErr').textContent = '';
  try {
    const s = await navigator.mediaDevices.getUserMedia({ audio: true });
    s.getTracks().forEach(t => t.stop());
    await mark({ mic: true }); next();
  } catch (e) {
    if (e.name === 'NotAllowedError' || e.name === 'SecurityError') { $('micDenied').hidden = false; await mark({ mic: false }); }
    else $('micErr').textContent = 'No microphone found. Plug one in, or continue and type instead. (' + e.message + ')';
  }
}

// ---------- 4. Optional context ----------
async function loadContext() {
  const { context = {} } = await get('context');
  $('role').value = context.role || ''; $('company').value = context.company || ''; $('jd').value = context.jd || '';
  const docs = await SS.docs(), r = docs.find(d => d.kind === 'resume');
  $('resumeMsg').textContent = r ? `Resume added: ${r.name}.` : '';
}
async function uploadResume(f) {
  $('resumeMsg').textContent = 'Reading ' + f.name + '…';
  const fd = new FormData(); fd.append('file', f);
  try {
    const r = await C.authFetch('/api/resume', { method: 'POST', body: fd }), j = await r.json();
    if (!r.ok) throw new Error(j.error); if (!j.text) throw new Error('No text found in it.');
    const docs = (await SS.docs()).filter(d => d.kind !== 'resume');
    docs.unshift({ id: 'd' + Date.now().toString(36), name: f.name.replace(/\.(pdf|docx|txt)$/i, ''), kind: 'resume', text: j.text.slice(0, 200000), addedAt: Date.now() });
    await SS.saveDocs(docs); await mark({ context: true });
    $('resumeMsg').textContent = `Resume added: ${f.name}.`;
  } catch (e) { $('resumeMsg').textContent = e.message || 'Could not read that file.'; }
}
async function saveContext() {
  const { context = {} } = await get('context');
  const c = { ...context, role: $('role').value.trim(), company: $('company').value.trim(), jd: $('jd').value.trim() };
  await chrome.storage.local.set({ context: c });
  if (c.role || c.jd) await mark({ context: true });
  next();
}

// ---------- 5. Practice run (free): speak the question, hear it through the mic, answer in the panel ----------
const QUESTION = 'Tell me about yourself.';
const P = { sid: null, stream: null, ctx: null, node: null, chunks: [], speech: 0, silence: 0, total: 0, queue: Promise.resolve(), heard: false, timer: null };
const tick = (id, ok = true) => $(id).classList.toggle('ok', ok);
async function preparePractice() {
  $('pErr').textContent = ''; $('pType').hidden = true; $('pNext').hidden = !O.practice;
  const mic = (await micState()) === 'granted';
  tick('pc-mic', mic); tick('pc-heard', false); tick('pc-answer', false);
  if (!mic) { $('pStatus').textContent = 'The microphone is off, so Cue will send the question as text instead.'; $('pPlay').textContent = 'Show me'; }
}
async function startPanel() {
  if (window.CueSession.state().on && P.sid) return true;
  if (window.CueSession.state().on) window.CueSession.stop();
  let s = null;
  try { s = await C.api('/api/session/start', { body: { practice: true, plannedMinutes: 3 } }); }
  catch (e) { $('pErr').textContent = e.code === 'practice' ? 'You have used the free practice runs. You can skip this step.' : e.message; }
  P.sid = s && s.sessionId;
  if (!P.sid) return false;
  await window.CueSession.start({ mode: 'interview', source: 'external', sessionId: P.sid, msLeft: s.msLeft, free: true, auto: true, creditMinutes: 6 });
  return true;
}
function endPanel() { stopMic(); if (window.CueSession.state().on) window.CueSession.stop(); P.sid = null; }

async function startMic() {
  // No echo cancellation here: Cue needs to hear the question it plays through the speakers.
  P.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: true } });
  P.ctx = new AudioContext({ sampleRate: 16000 });
  await P.ctx.audioWorklet.addModule('../offscreen/capture-worklet.js');
  P.node = new AudioWorkletNode(P.ctx, 'cue-capture');
  P.node.port.onmessage = e => onAudio(e.data);
  P.ctx.createMediaStreamSource(P.stream).connect(P.node); P.node.connect(P.ctx.destination);
  await P.ctx.resume();
}
function stopMic() { try { P.node && (P.node.port.onmessage = null); P.stream && P.stream.getTracks().forEach(t => t.stop()); P.ctx && P.ctx.close(); } catch (_) {} P.stream = P.ctx = P.node = null; P.chunks = []; }
function onAudio(d) {
  const ms = d.length / 16; let sum = 0; for (let i = 0; i < d.length; i++) sum += d[i] * d[i];
  const loud = Math.sqrt(sum / d.length) > 0.01;
  if (!P.chunks.length) { if (loud) { P.chunks = [d]; P.speech = P.total = ms; P.silence = 0; } return; }
  P.chunks.push(d); P.total += ms; if (loud) { P.speech += ms; P.silence = 0; } else P.silence += ms;
  if (P.silence >= 700 || P.total >= 12000) { const c = P.chunks, sp = P.speech; P.chunks = []; if (sp >= 300) transcribe(c); }
}
function wav(chunks) {
  const n = chunks.reduce((a, c) => a + c.length, 0), b = new DataView(new ArrayBuffer(44 + n * 2)), w = (o, s) => [...s].forEach((ch, i) => b.setUint8(o + i, ch.charCodeAt(0)));
  w(0, 'RIFF'); b.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); b.setUint32(16, 16, true); b.setUint16(20, 1, true); b.setUint16(22, 1, true);
  b.setUint32(24, 16000, true); b.setUint32(28, 32000, true); b.setUint16(32, 2, true); b.setUint16(34, 16, true); w(36, 'data'); b.setUint32(40, n * 2, true);
  let o = 44; for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) b.setInt16(o, Math.max(-1, Math.min(1, c[i])) * 0x7fff, true);
  return new Blob([b], { type: 'audio/wav' });
}
function transcribe(chunks) {
  if (!P.sid) return;
  P.queue = P.queue.then(async () => {
    try {
      const fd = new FormData(); fd.append('audio', wav(chunks), 'q.wav'); fd.append('lang', 'en');
      const r = await C.authFetch('/api/transcribe', { method: 'POST', body: fd }, P.sid), j = await r.json().catch(() => ({}));
      if (r.ok && j.text) window.CueProviders.External.push({ speaker: 'other', text: j.text, final: true });
    } catch (_) {}
  });
}
function speak(text) {
  return new Promise(resolve => {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); u.lang = 'en-IN'; u.rate = 0.95;
    const v = speechSynthesis.getVoices(); u.voice = v.find(x => x.lang === 'en-IN') || v.find(x => x.lang.startsWith('en')) || null;
    const done = () => { clearTimeout(t); resolve(); }, t = setTimeout(done, 6000);
    u.onend = done; u.onerror = done; speechSynthesis.speak(u);
  });
}
async function playPractice() {
  $('pPlay').disabled = true; $('pErr').textContent = ''; P.heard = false; tick('pc-heard', false); tick('pc-answer', false);
  if (!(await startPanel())) { $('pPlay').disabled = false; return; }
  if ((await micState()) !== 'granted') return typeInstead();
  try { if (!P.stream) await startMic(); tick('pc-mic'); }
  catch (e) { $('pErr').textContent = 'Could not open the microphone: ' + e.message; return typeInstead(); }
  $('pStatus').textContent = 'Playing the question…';
  await speak(QUESTION);
  $('pStatus').textContent = 'Listening…';
  clearTimeout(P.timer);
  P.timer = setTimeout(() => {
    if (P.heard) return;
    $('pStatus').textContent = "Cue didn't hear it. Turn your speakers up and play it again, or type it instead.";
    $('pType').hidden = false; $('pPlay').disabled = false; $('pPlay').textContent = 'Play again';
  }, 9000);
}
async function typeInstead() {
  if (!P.sid && !(await startPanel())) return;
  $('pStatus').textContent = 'Sending the question as text…';
  window.CueProviders.External.push({ speaker: 'other', text: QUESTION, final: true });
}
window.addEventListener('cue:heard', e => { if (step !== 'practice' || e.detail.speaker !== 'other') return; P.heard = true; tick('pc-heard'); $('pStatus').textContent = `Heard: “${e.detail.text}”. Writing an answer…`; });
window.addEventListener('cue:answer', async () => {
  if (step !== 'practice') return;
  clearTimeout(P.timer); stopMic();
  tick('pc-heard'); tick('pc-answer');
  $('pStatus').textContent = 'It works. That is how answers appear on a real call.';
  $('pPlay').hidden = true; $('pType').hidden = true; $('pSkip').hidden = true; $('pNext').hidden = false;
  await mark({ practice: true });
});

// ---------- 6. Controls: show/hide shortcut, drag, opacity ----------
let notchUI = true;
async function startControls() {
  // The notch has no opacity slider on it, so its third control is double-click to collapse.
  const { settings = {} } = await get('settings');
  notchUI = (settings.display || 'notch') === 'notch';
  $('cc3t').textContent = notchUI ? 'Shrink it' : 'See through it';
  $('cc3d').textContent = notchUI ? 'Double-click the panel to shrink it to a pill, then double-click again.' : 'Open the gear on the panel and move the opacity slider.';
  ['toggle', 'drag', 'opacity'].forEach(k => tick('cc-' + k, Boolean(O[k])));
  const cmds = await chrome.commands.getAll().catch(() => []);
  const key = (cmds.find(c => c.name === 'toggle-overlay') || {}).shortcut;
  $('kbd').textContent = key || 'no shortcut set';
  $('setKeys').hidden = Boolean(key);
  // The panel stays open from the practice run; if that was skipped, open it without a session (no AI, no credits).
  if (!window.CueSession.state().on) await window.CueSession.start({ mode: 'interview', source: 'external', free: true, creditMinutes: 6 });
}
window.addEventListener('cue:toggled', async () => { if (step !== 'controls') return; tick('cc-toggle'); await mark({ toggle: true }); });
window.addEventListener('cue:moved', async () => { if (step !== 'controls') return; tick('cc-drag'); await mark({ drag: true }); });
window.addEventListener('cue:collapsed', async () => { if (step !== 'controls' || !notchUI) return; tick('cc-opacity'); await mark({ opacity: true }); });
chrome.storage.onChanged.addListener(ch => {
  if (step === 'controls' && !notchUI && ch.settings && (ch.settings.newValue || {}).opacity !== (ch.settings.oldValue || {}).opacity) { tick('cc-opacity'); mark({ opacity: true }); }
});

// ---------- 7. Credits ----------
let quoteMin = 120;
async function renderCredits() {
  try { acct = acct || await C.api('/api/account'); } catch (e) { $('qsum').textContent = e.message; return; }
  const p = acct.pricing, q = C.quote(quoteMin, 0, p);
  $('qsum').textContent = q.summary;
  $('qsub').textContent = `${p.creditMinutes} minutes per credit. Credits are only used while a session runs.`;
  if (acct.credits) $('freeLine').textContent = `Your first ${C.dur(acct.credits * p.creditMinutes)} are free. Before a longer interview, tell us how long it is and we'll show the price.`;
  $('qchips').querySelectorAll('button').forEach(b => b.classList.toggle('sel', +b.dataset.m === quoteMin));
}

// ---------- 8. Done: checklist ----------
function paintChecks() {
  const controls = O.toggle && O.drag && O.opacity;
  [['dc-pinned', O.pinned], ['dc-mic', O.mic], ['dc-context', O.context], ['dc-practice', O.practice], ['dc-controls', controls]].forEach(([id, ok]) => tick(id, Boolean(ok)));
}
async function finish() {
  let pinned = O.pinned; try { pinned = (await chrome.action.getUserSettings()).isOnToolbar || pinned; } catch (_) {}
  await mark({ done: true, pinned, mic: (await micState()) === 'granted' || O.mic });
}

// ---------- wiring ----------
document.querySelectorAll('[data-next]').forEach(b => b.addEventListener('click', next));
document.querySelectorAll('[data-skip]').forEach(b => b.addEventListener('click', next));
document.querySelectorAll('[data-goto]').forEach(b => b.addEventListener('click', () => show(b.dataset.goto)));
$('micAllow').onclick = async () => ((await micState()) === 'granted' ? next() : askMic());
$('micRetry').onclick = askMic;
$('micSettings').onclick = () => chrome.tabs.create({ url: 'chrome://settings/content/microphone' });
$('resumeFile').onchange = e => { const f = e.target.files[0]; if (f) uploadResume(f); };
$('ctxSave').onclick = saveContext;
$('pPlay').onclick = playPractice;
$('pType').onclick = typeInstead;
$('setKeys').onclick = () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
$('qchips').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { quoteMin = +b.dataset.m; renderCredits(); } });

// Links to a step (welcome.html#practice) work on an open guide too.
addEventListener('hashchange', () => { const h = location.hash.slice(1); if (STEPS.includes(h) && h !== step) show(h); });

(async () => {
  STEPS.forEach(() => $('dots').appendChild(document.createElement('li')));
  O = (await get('onboarding')).onboarding || {};
  paintChecks();
  playClip();
  const want = location.hash.slice(1);
  show(STEPS.includes(want) ? want : O.done ? 'done' : 'welcome');
})();
