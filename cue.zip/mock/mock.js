// Mock interview: an AI interviewer speaks each question, listens to the spoken answer, asks follow-ups,
// and writes feedback at the end. Runs as its own page, so no call tab is needed.
const $ = id => document.getElementById(id);
const C = self.CueClient, SS = self.CueSessions;
const SR = 16000, THRESH = 0.012, PHRASE_MS = 700, ANSWER_MS = 2500, MIN_SPEECH_MS = 300, MAX_PHRASE_MS = 15000, BEAT_MS = 30_000;
const id = new URLSearchParams(location.search).get('id');
const M = { rec: null, acct: null, sid: null, msLeft: 0, leftAt: 0, startedAt: 0, free: false, history: [], transcript: [], q: '',
  answer: [], listening: false, ended: false, stream: null, ctx: null, node: null, queue: Promise.resolve(), pending: 0,
  chunks: [], speechMs: 0, silenceMs: 0, totalMs: 0, heardAny: false, quietMs: 0, tick: null, beat: null };

const fmt = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
const err = t => { $('err').textContent = t || ''; };
const state = (cls, text) => { const w = $('live').querySelector('.stage'); w.classList.remove('speaking', 'thinking', 'listening'); if (cls) w.classList.add(cls); $('state').textContent = text; };
const show = sec => ['intro', 'live', 'after'].forEach(x => ($(x).hidden = x !== sec));

async function load() {
  M.rec = id && await SS.get(id);
  if (!M.rec) { $('title').textContent = 'Session not found'; err('Open mock interviews from Sessions in Cue settings.'); return; }
  $('title').textContent = M.rec.title;
  $('meta').textContent = [M.rec.role, M.rec.company, C.dur(M.rec.plannedMinutes || 15)].filter(Boolean).join(' · ');
  $('open').href = '../options/options.html#session=' + encodeURIComponent(id);
  if (M.rec.status === 'ended') { show('after'); $('feedback').textContent = M.rec.notes || 'No feedback was saved for this interview.'; return; }
  try { M.acct = await C.api('/api/account'); } catch (e) { err(e.message); }
  const p = M.acct && M.acct.pricing;
  $('costNote').textContent = !M.acct ? '' : M.acct.freeMock ? 'Your first mock interview is free for 15 minutes.'
    : `Uses credits like any session: ${p.creditMinutes} minutes per credit, only for time actually spent. You have ${M.acct.credits}.`;
  show('intro');
}

// ---------- speaking ----------
let voices = [];
const loadVoices = () => { voices = speechSynthesis.getVoices(); };
speechSynthesis.onvoiceschanged = loadVoices; loadVoices();
function speak(text) {
  return new Promise(resolve => {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text), lang = M.rec.lang === 'hi' ? 'hi-IN' : 'en-IN';
    u.lang = lang; u.rate = 1;
    u.voice = voices.find(v => v.lang === lang) || voices.find(v => v.lang.startsWith(lang.slice(0, 2))) || null;
    // Some voices never fire onend; finish after a generous estimate instead of hanging.
    const done = () => { clearTimeout(t); resolve(); }, t = setTimeout(done, 4000 + text.length * 90);
    u.onend = done; u.onerror = done;
    speechSynthesis.speak(u);
  });
}

// ---------- listening ----------
async function startMic() {
  M.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  M.ctx = new AudioContext({ sampleRate: SR });
  await M.ctx.audioWorklet.addModule('../offscreen/capture-worklet.js');
  M.node = new AudioWorkletNode(M.ctx, 'cue-capture');
  M.node.port.onmessage = e => onAudio(e.data);
  M.ctx.createMediaStreamSource(M.stream).connect(M.node);
  M.node.connect(M.ctx.destination); // keeps the node running; it outputs silence
  await M.ctx.resume();
}
function stopMic() {
  try { M.node && (M.node.port.onmessage = null); M.stream && M.stream.getTracks().forEach(t => t.stop()); M.ctx && M.ctx.close(); } catch (_) {}
  M.stream = M.ctx = M.node = null;
}

function onAudio(d) {
  if (!M.listening) return;
  const ms = (d.length / SR) * 1000;
  let sum = 0; for (let i = 0; i < d.length; i++) sum += d[i] * d[i];
  const rms = Math.sqrt(sum / d.length), loud = rms > THRESH;
  const lit = Math.min(8, Math.round(rms / THRESH * 2));
  $('meter').querySelectorAll('i').forEach((x, i) => x.classList.toggle('on', i < lit));
  if (!M.chunks.length) {
    if (loud) { M.chunks = [d]; M.speechMs = M.totalMs = ms; M.silenceMs = 0; M.quietMs = 0; }
    else if (M.heardAny) { M.quietMs += ms; if (M.quietMs >= ANSWER_MS && !M.pending) finishAnswer(); }
    return;
  }
  M.chunks.push(d); M.totalMs += ms;
  if (loud) { M.speechMs += ms; M.silenceMs = 0; } else M.silenceMs += ms;
  if (M.silenceMs >= PHRASE_MS || M.totalMs >= MAX_PHRASE_MS) {
    const c = M.chunks, sp = M.speechMs; M.chunks = []; M.quietMs = M.silenceMs;
    if (sp >= MIN_SPEECH_MS) { M.heardAny = true; transcribe(c); }
  }
}

function wav(chunks) {
  const n = chunks.reduce((a, c) => a + c.length, 0), buf = new DataView(new ArrayBuffer(44 + n * 2));
  const w = (o, s) => [...s].forEach((ch, i) => buf.setUint8(o + i, ch.charCodeAt(0)));
  w(0, 'RIFF'); buf.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); buf.setUint32(16, 16, true); buf.setUint16(20, 1, true);
  buf.setUint16(22, 1, true); buf.setUint32(24, SR, true); buf.setUint32(28, SR * 2, true); buf.setUint16(32, 2, true); buf.setUint16(34, 16, true);
  w(36, 'data'); buf.setUint32(40, n * 2, true);
  let o = 44; for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) buf.setInt16(o, Math.max(-1, Math.min(1, c[i])) * 0x7fff, true);
  return new Blob([buf], { type: 'audio/wav' });
}

function transcribe(chunks) {
  M.pending++;
  M.queue = M.queue.then(async () => {
    try {
      const fd = new FormData(); fd.append('audio', wav(chunks), 'answer.wav'); fd.append('lang', M.rec.lang || 'auto');
      const r = await C.authFetch('/api/transcribe', { method: 'POST', body: fd }, M.sid);
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { if (j.code === 'session' || j.code === 'credits') return timeUp(j.error); throw new Error(j.error || 'Transcription failed.'); }
      if (j.text) { M.answer.push(j.text); $('answer').textContent = M.answer.join(' '); }
    } catch (e) { err(e.message); }
    finally { M.pending--; }
  });
}

// ---------- the interview ----------
const context = async () => {
  const docs = await SS.docs();
  return { role: M.rec.role, company: M.rec.company, instructions: M.rec.instructions, lang: M.rec.lang || 'auto',
    resume: docs.filter(d => d.kind === 'resume').map(d => d.text).join('\n\n') };
};

async function ask() {
  if (M.ended) return;
  M.listening = false; state('thinking', 'Interviewer is thinking');
  $('done').disabled = true;
  let say;
  try {
    const r = await C.authFetch('/api/mock/next', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...(await context()), history: M.history }) }, M.sid);
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { if (j.code === 'session' || j.code === 'credits') return timeUp(j.error); throw new Error(j.error || 'The interviewer could not continue.'); }
    say = j.say;
  } catch (e) { err(e.message + ' Press Repeat question to try again.'); state('', 'Paused'); return; }
  M.q = say; $('say').textContent = say; M.transcript.push({ speaker: 'other', text: say, at: Date.now() - M.startedAt });
  await sayAndListen();
}

async function sayAndListen() {
  if (M.ended) return;
  M.listening = false; err('');
  state('speaking', 'Interviewer is speaking');
  await speak(M.q);
  if (M.ended) return;
  M.answer = []; M.chunks = []; M.heardAny = false; M.quietMs = 0; $('answer').textContent = '';
  M.listening = true; $('done').disabled = false;
  state('listening', 'Your turn. Answer out loud');
}

async function finishAnswer() {
  if (!M.listening || M.ended) return;
  M.listening = false; $('done').disabled = true;
  if (M.chunks.length) { const c = M.chunks; M.chunks = []; transcribe(c); }   // the phrase still being spoken
  state('thinking', 'Got it');
  await M.queue;
  const a = M.answer.join(' ').trim();
  M.history.push({ q: M.q, a });
  if (a) M.transcript.push({ speaker: 'me', text: a, at: Date.now() - M.startedAt });
  ask();
}

// ---------- session and time ----------
const localLeft = () => M.msLeft - (Date.now() - M.leftAt);
function showClock() {
  const elapsed = Date.now() - M.startedAt, planned = (M.rec.plannedMinutes || 15) * 60_000;
  const left = Math.min(localLeft(), planned - elapsed);
  $('timer').textContent = fmt(elapsed);
  $('left').textContent = `${fmt(left)} left${M.free ? ' · free' : ''}`;
  $('left').classList.toggle('warn', left < 2 * 60_000);
  if (left <= 0) timeUp('Time is up.');
}
async function beat() {
  if (M.ended || !M.sid) return;
  try {
    const r = await C.api('/api/session/beat', { body: { sessionId: M.sid } });
    M.msLeft = r.msLeft; M.leftAt = Date.now();
    if (r.status !== 'live') timeUp(r.timeUp ? 'Your free 15 minutes are up.' : 'This session has ended.');
  } catch (_) {}
}

async function begin() {
  $('begin').disabled = true; err('');
  try { await startMic(); }
  catch (e) { $('begin').disabled = false; return err('Cue needs your microphone for the mock interview. Allow it in the address bar, then press Start again. (' + e.message + ')'); }
  let s;
  try { s = await C.api('/api/session/start', { body: { mock: true, plannedMinutes: M.rec.plannedMinutes || 15 } }); }
  catch (e) { stopMic(); $('begin').disabled = false; return err(e.code === 'credits' ? 'You have no credits. Add credits in Cue settings, then start again.' : e.message); }
  M.sid = s.sessionId; M.msLeft = s.msLeft; M.leftAt = Date.now(); M.startedAt = Date.now(); M.free = s.free;
  const tab = await chrome.tabs.getCurrent().catch(() => null);
  await SS.update(id, { status: 'live', startedAt: M.startedAt, serverSessionId: M.sid, tabId: tab ? tab.id : null, armedAt: null });
  $('clock').hidden = false; show('live');
  M.tick = setInterval(showClock, 1000); M.beat = setInterval(beat, BEAT_MS); showClock();
  ask();
}

function timeUp(msg) { if (!M.ended) { err(msg || ''); end(); } }

async function end() {
  if (M.ended) return;
  M.ended = true; M.listening = false;
  speechSynthesis.cancel(); clearInterval(M.tick); clearInterval(M.beat);
  if (M.chunks.length && M.sid) { const c = M.chunks; M.chunks = []; transcribe(c); }
  await M.queue; stopMic();
  // Keep a half-finished answer to the last question.
  const a = M.answer.join(' ').trim();
  if (M.q && !M.history.some(t => t.q === M.q)) { M.history.push({ q: M.q, a }); if (a) M.transcript.push({ speaker: 'me', text: a, at: Date.now() - M.startedAt }); }
  show('after'); $('clock').hidden = true;
  let used = null;
  if (M.sid) { try { used = (await C.api('/api/session/end', { body: { sessionId: M.sid } })).usedCredits; } catch (_) {} }
  const endedAt = Date.now();
  await SS.update(id, { status: 'ended', endedAt, durationMs: endedAt - M.startedAt, creditsUsed: used, transcript: M.transcript.length ? M.transcript : null, tabId: null });
  let feedback;
  try { feedback = (await C.api('/api/mock/feedback', { body: { ...(await context()), history: M.history } })).feedback; }
  catch (e) { feedback = 'Could not write feedback: ' + e.message + '. Open the session page to try AI notes instead.'; }
  $('feedback').textContent = feedback;
  await SS.update(id, { notes: feedback });
}

$('begin').onclick = begin;
$('done').onclick = finishAnswer;
$('repeat').onclick = () => { if (M.q) sayAndListen(); else ask(); };
$('end').onclick = () => { if (confirm('End the interview and get feedback?')) end(); };
// If the tab is closed mid-interview, heartbeats stop and the server ends the session within 3 minutes.
load();
