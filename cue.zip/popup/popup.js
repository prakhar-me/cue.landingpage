const $ = id => document.getElementById(id);
const C = self.CueClient, SS = self.CueSessions;
let tabId = null, on = false, ready = false, acct = null, minutes = 60, busy = false, sessions = [];
const sel = id => document.querySelector(`#${id} .sel`).dataset.v;
const SRC = { tab: 'Hears the other side through this tab.', tabmic: 'Also logs your own answers from the mic.', mock: 'Scripted interviewer lines for a demo. Uses credits.' };
const chosen = () => sessions.find(s => s.id === $('sess').value) || null;   // null = quick session

['mode', 'src'].forEach(id => $(id).addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  $(id).querySelectorAll('button').forEach(x => x.classList.toggle('sel', x === b));
  render();
}));
$('chips').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setMinutes(+b.dataset.m); });
$('minus').onclick = () => setMinutes(minutes - 15);
$('plus').onclick = () => setMinutes(minutes + 15);
$('sess').onchange = render;

function setMinutes(m) {
  const p = acct ? acct.pricing : { minMinutes: 15, maxMinutes: 480 };
  minutes = Math.min(p.maxMinutes, Math.max(p.minMinutes, Math.round(m / 15) * 15));
  chrome.storage.local.get('settings', v => chrome.storage.local.set({ settings: { ...(v.settings || {}), plannedMinutes: minutes } }));
  render();
}

async function loadSessions() {
  // Ready sessions for calls; mock interviews start from the Sessions page instead.
  sessions = (await SS.list()).filter(s => s.status === 'ready' && s.mode !== 'mock')
    .sort((a, b) => (b.armedAt || 0) - (a.armedAt || 0) || b.createdAt - a.createdAt);
  const keep = $('sess').value;
  $('sess').textContent = '';
  sessions.forEach(s => $('sess').add(new Option(`${s.title} · ${SS.MODE_LABEL[s.mode]} · ${C.dur(s.plannedMinutes || 30)}`, s.id)));
  $('sess').add(new Option('Quick session, no setup', ''));
  $('sess').value = sessions.some(s => s.id === keep) ? keep : sessions[0] ? sessions[0].id : '';
}

function planned() { const s = chosen(); return s ? Math.max(15, s.plannedMinutes || 30) : minutes; }

function render() {
  const s = chosen();
  $('quick').hidden = Boolean(s);
  $('sessd').textContent = s ? [s.company, s.role].filter(Boolean).join(' · ') + (s.instructions ? ` · ${s.instructions.length.toLocaleString()} characters of instructions` : '') : 'Uses your profile and documents. Set up a session for a job description or notes.';
  $('durq').textContent = sel('mode') === 'call' ? 'How long is the call?' : 'How long is the interview?';
  $('srcd').textContent = SRC[sel('src')];
  $('durv').textContent = C.dur(minutes);
  document.querySelectorAll('#chips button').forEach(b => b.classList.toggle('sel', +b.dataset.m === minutes));
  $('alt').hidden = true; $('go').classList.remove('pay');
  if (on) { $('go').textContent = 'Stop session'; $('go').disabled = false; return; }
  if (!acct) { $('qsum').textContent = '…'; $('go').textContent = 'Start session'; $('go').disabled = true; return; }
  const p = acct.pricing, q = C.quote(planned(), acct.credits, p);
  $('cm').textContent = p.creditMinutes;
  $('bal').textContent = acct.credits; $('balm').textContent = acct.credits === 1 ? 'credit' : 'credits';
  $('qsum').textContent = q.summary;
  if (!q.buy) {
    $('qsub').textContent = `Covered by your balance of ${acct.credits} credits. You only use credits for time spent.`;
    $('go').textContent = 'Start session'; $('go').disabled = !ready || busy;
  } else {
    const what = q.buy.pack ? q.buy.label.replace(/, \d+ credits$/, '') + ` (${q.buy.credits} credits)` : `${q.buy.credits} credits`;
    $('qsub').textContent = (acct.credits ? `You have ${acct.credits} credits. ` : '') + `Buy ${what} for ${C.rupees(q.buy.pricePaise)}, then press Start. Unused credits go back to your balance.`;
    $('go').textContent = 'Pay & Start'; $('go').classList.add('pay'); $('go').disabled = busy;
    if (acct.credits > 0 && ready) { $('alt').hidden = false; $('alt').textContent = `Start with my ${C.dur(acct.minutesLeft)} balance instead`; }
  }
}

async function refresh() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = tab && tab.id;
  try { on = (await chrome.tabs.sendMessage(tabId, { type: 'status' })).on; ready = true; }
  catch { on = false; ready = false; }
  $('hero').classList.toggle('on', on);
  $('st').textContent = on ? 'Session running' : ready ? 'Ready' : 'Not on a meeting tab';
  $('sd').textContent = on ? 'Cue is active on this tab' : ready ? 'Pick a session and start' : 'Open Meet, Zoom or Teams, then reload it once';
  $('go').classList.toggle('stop', on);
  render();
}

async function loadAccount() {
  try { acct = await C.api('/api/account'); $('err').textContent = ''; }
  catch (e) { acct = null; $('bal').textContent = '–'; $('err').textContent = e.message; }
  render();
}

async function pay(buy) {
  busy = true; render();
  try {
    const o = await C.api('/api/billing/order', { body: C.orderBody(buy) });
    chrome.tabs.create({ url: o.payUrl });
    window.close();
  } catch (e) { $('err').textContent = e.message; }
  busy = false; render();
}

async function start() {
  busy = true; render(); $('err').textContent = '';
  const source = sel('src');
  if (source !== 'mock') {
    const h = await fetch((await C.backend()) + '/health').then(r => r.json()).catch(() => null);
    if (h && h.sttConfigured === false) {
      $('err').textContent = 'Cue cannot hear the call yet: the backend has no OPENAI_API_KEY for transcription. Add it to backend/.env and restart, or pick Sample.';
      busy = false; return render();
    }
  }
  // A quick session still gets a record, so it shows up in Sessions with its transcript and notes.
  const { settings = {} } = await chrome.storage.local.get('settings');
  const rec = chosen() || await SS.create({ title: sel('mode') === 'call' ? 'Quick call' : 'Quick interview', mode: sel('mode'), plannedMinutes: minutes, lang: settings.lang || 'auto', saveTranscript: Boolean(settings.saveTranscripts) });
  let s;
  try { s = await C.api('/api/session/start', { body: { plannedMinutes: planned() } }); }
  catch (e) { $('err').textContent = e.message; busy = false; await loadAccount(); return; }
  const undo = async msg => { $('err').textContent = msg; chrome.runtime.sendMessage({ type: 'capture:stop' }); await C.api('/api/session/end', { body: { sessionId: s.sessionId } }).catch(() => {}); busy = false; loadAccount(); };
  if (source !== 'mock') {
    const r = await chrome.runtime.sendMessage({ type: 'capture:start', tabId, session: s.sessionId });
    if (!r || !r.ok) return undo('Could not capture this tab\'s audio: ' + ((r && r.error) || 'unknown error'));
  }
  let r;
  try { r = await chrome.tabs.sendMessage(tabId, { type: 'start', recordId: rec.id, source, sessionId: s.sessionId, msLeft: s.msLeft, tabId, creditMinutes: acct.pricing.creditMinutes }); }
  catch (e) { return undo('Cue lost contact with this tab (' + e.message + '). Reload the meeting tab and try again.'); }
  if (r && r.ok === false) return undo('Cue could not start on this tab: ' + r.error);
  window.close();
}

$('go').onclick = async () => {
  if (on) { await chrome.tabs.sendMessage(tabId, { type: 'stop' }).catch(() => {}); await refresh(); return loadAccount(); }
  if (!acct) return loadAccount();
  const q = C.quote(planned(), acct.credits, acct.pricing);
  if (q.buy) return pay(q.buy);
  start();
};
$('alt').onclick = e => { e.preventDefault(); start(); };

// What changed in this version, shown once after an update (with the NEW badge on the icon).
const WHATS_NEW = 'guided setup and a free practice run.';
chrome.storage.local.get(['whatsNew', 'onboarding'], ({ whatsNew, onboarding = {} }) => {
  if (whatsNew) { $('whatsNew').hidden = false; $('wnText').textContent = `New in ${whatsNew}: ${WHATS_NEW}`; }
  const left = ['pinned', 'mic', 'practice'].filter(k => !onboarding[k]).length + (onboarding.toggle && onboarding.drag && onboarding.opacity ? 0 : 1);
  if (left) { $('setupLink').hidden = false; $('setupLink').textContent = `Finish setup (${left} left)`; }
});
$('wnClose').onclick = () => { chrome.storage.local.remove('whatsNew'); chrome.action.setBadgeText({ text: '' }); $('whatsNew').hidden = true; };
$('setupLink').onclick = e => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL('welcome/welcome.html#done') }); };
document.querySelectorAll('a[data-p]').forEach(a => a.onclick = e => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL('options/options.html#' + a.dataset.p) }); });
chrome.storage.local.get(['settings'], async ({ settings = {} }) => {
  if (settings.plannedMinutes) minutes = settings.plannedMinutes;
  await loadSessions();
  refresh(); loadAccount();
});
