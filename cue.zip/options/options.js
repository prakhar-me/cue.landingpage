const $ = id => document.getElementById(id);
const C = self.CueClient;
const F = ['name', 'currentRole', 'years', 'skills'];

function addProject(p = {}) {
  const d = document.createElement('div'); d.className = 'proj';
  d.innerHTML = '<input data-k="name" placeholder="Project"><input data-k="description" placeholder="Description"><input data-k="role" placeholder="My role"><input data-k="impact" placeholder="Impact">';
  d.querySelectorAll('input').forEach(i => (i.value = p[i.dataset.k] || ''));
  $('projects').appendChild(d);
}
$('addp').onclick = () => addProject();

async function load() {
  const { context = {}, settings = {} } = await chrome.storage.local.get(['context', 'settings']);
  F.forEach(k => ($(k).value = context[k] || ''));
  (context.projects && context.projects.length ? context.projects : [{}]).forEach(addProject);
  $('auto').checked = settings.autoAnswer === true; $('saveT').checked = !!settings.saveTranscripts; $('backend').value = settings.backend || ''; $('lang').value = settings.lang || 'auto'; $('english').value = settings.english || 'polished'; $('display').value = settings.display || 'notch'; $('notchMode').value = settings.notchMode || 'auto'; $('opacity').value = settings.opacity || 40; $('opv').textContent = $('opacity').value + '%';
}

$('save').onclick = async () => {
  // Merge, so values set elsewhere (role and company from the welcome demo) are kept.
  const { context: prev = {} } = await chrome.storage.local.get('context');
  const context = { ...prev }; F.forEach(k => (context[k] = $(k).value));
  context.projects = [...document.querySelectorAll('.proj')].map(d => Object.fromEntries([...d.querySelectorAll('input')].map(i => [i.dataset.k, i.value]))).filter(p => p.name);
  const { settings = {} } = await chrome.storage.local.get('settings');
  await chrome.storage.local.set({ context, settings: { ...settings, backend: $('backend').value.trim(), autoAnswer: $('auto').checked, saveTranscripts: $('saveT').checked, lang: $('lang').value, english: $('english').value, display: $('display').value, notchMode: $('notchMode').value, opacity: +$('opacity').value } });
  $('msg').textContent = 'Saved.';
};
$('wipe').onclick = async () => {
  if (!confirm('Delete your profile, documents, projects, sessions and settings from this browser? Your credits and recovery key are kept.')) return;
  const { account } = await chrome.storage.local.get('account');
  await chrome.storage.local.clear(); if (account) await chrome.storage.local.set({ account }); location.reload();
};
load();
$('opacity').addEventListener('input', e => { $('opv').textContent = e.target.value + '%'; });

// Pages: #sessions, #new, #session=<id>, #documents, #projects, #profile, #billing, #settings.
// Older links (#interview, #resume) land on their replacements.
function show() {
  let h = (location.hash || '#sessions').slice(1);
  h = { interview: 'new', resume: 'documents' }[h] || h;
  const page = h.split('=')[0], nav = page === 'session' ? 'sessions' : page;
  document.querySelectorAll('section').forEach(x => x.classList.toggle('cur', x.dataset.page === page));
  document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('cur', a.getAttribute('href') === '#' + nav));
  document.querySelector('footer').style.display = ['projects', 'profile', 'settings'].includes(page) ? '' : 'none';
  if (page === 'billing') loadBilling();
  if (window.CueOptions) window.CueOptions.show(page, h.split('=')[1]);
}
addEventListener('hashchange', show); show();

const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x !== undefined) e.textContent = x; return e; };
const dur = ms => { const m = Math.round(ms / 60000); return m < 1 ? '<1 min' : m + ' min'; };

// ---- Credits and billing ----
let acct = null, buyMin = 45;
const REASON = { purchase: 'Bought credits', session: 'Session', welcome: 'Free trial credits', referral: 'Referral credits', coupon: 'Coupon' };

async function loadBilling() {
  try { acct = await C.api('/api/account'); $('bmsg').textContent = ''; }
  catch (e) { acct = null; $('bmsg').textContent = e.message; }
  renderBilling();
}

function renderBilling() {
  document.querySelectorAll('#bchips button').forEach(b => b.classList.toggle('sel', +b.dataset.m === buyMin));
  if (!acct) { $('buy').disabled = true; $('bq').textContent = '…'; return; }
  const p = acct.pricing, q = C.quote(buyMin, 0, p), hr = 60 / p.creditMinutes;
  $('bc').textContent = acct.credits; $('bm').textContent = C.dur(acct.minutesLeft); $('bp').textContent = C.rupees(p.pricePerCreditPaise);
  $('how').textContent = `1 credit is ${p.creditMinutes} minutes of live session, ${C.rupees(p.pricePerCreditPaise)} pay as you go (${C.rupees(p.pricePerCreditPaise * hr)} an hour). Cue spends credits only while a session runs, in ${p.creditMinutes} minute steps, and never while paused. Book 60 minutes and finish in 40, and the rest stays in your balance. Credits never expire. If you stop in the first minute before any answer, the credit comes back. Every new account gets ${p.signupCredits} free credits (${C.dur(p.signupCredits * p.creditMinutes)}) to try Cue. No extra charges at checkout.`;
  $('paygNote').textContent = `${C.rupees(p.pricePerCreditPaise)} per credit, minimum ${p.minPurchaseCredits} credits (${C.rupees(p.minPurchaseCredits * p.pricePerCreditPaise)}). How long is your next interview or meeting?`;
  // Packs
  const P = $('packs'); P.textContent = '';
  const bestPerHour = Math.min(...p.packs.map(k => k.pricePaise / k.credits));
  p.packs.forEach(k => {
    const perHour = Math.round(k.pricePaise / k.credits * hr / 100) * 100, payg = k.credits * p.pricePerCreditPaise;
    const d = el('div', 'pack' + (k.pricePaise / k.credits === bestPerHour ? ' best' : ''));
    if (k.pricePaise / k.credits === bestPerHour) d.appendChild(el('span', 'tag', 'Best value'));
    d.append(el('h4', '', k.name), el('div', 'price', C.rupees(k.pricePaise)), el('span', 'meta', `${k.credits} credits · ${C.dur(k.credits * p.creditMinutes)}`), el('span', 'meta', `${C.rupees(perHour)} per hour`));
    if (payg - k.pricePaise >= 1000) d.appendChild(el('span', 'save', `Save ${C.rupees(payg - k.pricePaise)}`));
    const b = el('button', 'primary', 'Buy'); b.type = 'button'; b.onclick = () => checkout({ pack: k.id }, b, 'pmsg'); d.appendChild(b);
    P.appendChild(d);
  });
  // Pay as you go: the quote already switches to a pack when that is cheaper.
  $('bq').textContent = q.summary;
  $('bqs').textContent = (q.buy.pack ? `${q.buy.label.replace(/, \d+ credits$/, '')} is cheaper: ${q.buy.credits} credits for ${C.rupees(q.buy.pricePaise)}.` : q.buy.credits > q.credits ? `Minimum purchase is ${q.buy.credits} credits.` : '')
    + (acct.credits ? ` You will have ${acct.credits + q.buy.credits} credits.` : '');
  $('buy').textContent = `Pay ${C.rupees(q.buy.pricePaise)}`; $('buy').disabled = false;
  // Referrals
  const ref = acct.referral;
  $('refCode').value = ref.code;
  $('refNote').textContent = `Share your code. When a friend adds it and makes their first purchase, you both get ${ref.credits} free credits.`;
  $('refApplyRow').hidden = !ref.canApply;
  if (ref.applied) $('refMsg').textContent = `A friend's code is applied. You both get ${ref.credits} credits with your first purchase.`;
  const L = $('ledger'); L.textContent = '';
  if (!acct.ledger.length) L.appendChild(el('p', 'note', 'No purchases or sessions yet.'));
  acct.ledger.forEach(x => {
    const r = el('div', 'lrow');
    const what = x.reason === 'session' ? `Session, ${dur(x.activeMs || 0)} live` : REASON[x.reason] || x.reason;
    r.append(el('span', '', new Date(x.at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })), el('span', '', what + (x.amountPaise ? ` · ${C.rupees(x.amountPaise)}` : '')),
      el('b', x.delta > 0 ? 'plus' : 'minus', (x.delta > 0 ? '+' : '') + x.delta));
    L.appendChild(r);
  });
}

const setBuy = m => { buyMin = Math.min(480, Math.max(15, Math.round(m / 15) * 15 || 15)); $('bmin').value = buyMin; renderBilling(); };
$('bchips').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setBuy(+b.dataset.m); });
$('bmin').addEventListener('change', e => setBuy(+e.target.value));
async function checkout(body, btn, msg) {
  btn.disabled = true; $(msg).textContent = 'Opening checkout…';
  try { const o = await C.api('/api/billing/order', { body }); chrome.tabs.create({ url: o.payUrl }); $(msg).textContent = 'Finish paying in the new tab. Your balance updates here when it is done.'; }
  catch (e) { $(msg).textContent = e.message; }
  btn.disabled = false;
}
$('buy').onclick = () => checkout(C.orderBody(C.quote(buyMin, 0, acct.pricing).buy), $('buy'), 'bmsg');
$('couponForm').onsubmit = async e => {
  e.preventDefault();
  const code = $('coupon').value.trim(); if (!code) return;
  $('couponApply').disabled = true; $('couponMsg').textContent = 'Checking…';
  try { const r = await C.api('/api/account/coupon', { body: { code } }); acct = r; $('coupon').value = ''; $('couponMsg').textContent = `Added ${r.added} credits. You now have ${r.credits}.`; renderBilling(); }
  catch (err) { $('couponMsg').textContent = err.message; }
  $('couponApply').disabled = false;
};
$('refCopy').onclick = async () => { await navigator.clipboard.writeText($('refCode').value); $('refMsg').textContent = 'Referral code copied.'; };
$('refApply').onclick = async () => {
  const code = $('refIn').value.trim().toUpperCase(); if (!code) return;
  try { acct = await C.api('/api/account/referral', { body: { code } }); $('refIn').value = ''; renderBilling(); }
  catch (e) { $('refMsg').textContent = e.message; }
};

let shown = false;
$('show').onclick = async () => { shown = !shown; $('key').value = shown ? (await C.token()) : '••••••••••••••••'; $('show').textContent = shown ? 'Hide' : 'Show'; };
$('copy').onclick = async () => { await navigator.clipboard.writeText(await C.token()); $('kmsg').textContent = 'Recovery key copied.'; };
$('restore').onclick = async () => {
  const t = $('rkey').value.trim(); if (!/^cue_[\w-]{20,}$/.test(t)) { $('kmsg').textContent = 'That does not look like a Cue recovery key.'; return; }
  const r = await fetch((await C.backend()) + '/api/account', { headers: { Authorization: 'Bearer ' + t } }).catch(() => null);
  if (!r || !r.ok) { $('kmsg').textContent = r ? 'No account found for that key.' : 'Cannot reach the Cue backend.'; return; }
  const cur = (await chrome.storage.local.get('account')).account;
  if (cur && cur.token !== t && !confirm('Switch this browser to the restored account? Credits on the current key stay on that key.')) return;
  await chrome.storage.local.set({ account: { token: t, restoredAt: Date.now(), backend: (await C.backend()) } });
  $('rkey').value = ''; $('kmsg').textContent = 'Restored.'; loadBilling();
};

// Pick up payments made in the checkout tab.
addEventListener('focus', () => { if (location.hash === '#billing') loadBilling(); });
setInterval(() => { if (document.visibilityState === 'visible' && location.hash === '#billing') loadBilling(); }, 5000);
