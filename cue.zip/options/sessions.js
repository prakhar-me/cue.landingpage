// Sessions list, New session form, session page (AI Notes / Transcript / Ask AI) and Documents.
// Uses $, C, el and dur from options.js.
(function () {
  const SS = self.CueSessions;
  const STATUS = { ready: 'Ready', live: 'Live', ended: 'Ended' };
  const fmtDate = t => new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  const minutesOf = s => (s.status === 'ended' ? dur(s.durationMs || 0) : C.dur(s.plannedMinutes || 30));
  let acct = null;
  const account = async () => (acct = await C.api('/api/account'));

  // ---------- Starting a session ----------
  // Calls need the Cue icon clicked on the call tab (Chrome only lets an extension capture a tab after that),
  // so a call session is marked as next-up and the popup preselects it. Mock interviews open their own page.
  async function startSession(s) {
    if (s.mode === 'mock') { chrome.tabs.create({ url: chrome.runtime.getURL('mock/mock.html?id=' + encodeURIComponent(s.id)) }); return; }
    await SS.update(s.id, { armedAt: Date.now() });
    guide(`<b>“${escapeHtml(s.title)}” is ready.</b><ol><li>Open your call in Google Meet, Zoom or Teams in Chrome.</li><li>Click the Cue icon in the toolbar. This session is already selected.</li><li>Press <b>Start session</b>.</li></ol>`);
    location.hash = '#sessions';
  }
  const escapeHtml = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function guide(html) { const g = $('guide'); g.hidden = !html; g.innerHTML = html || ''; if (html) g.scrollIntoView({ block: 'nearest' }); }

  async function join(s) {
    if (s.tabId == null) { guide('<b>This session is running in a tab Cue cannot find.</b> Switch to your call tab, or end the session from the panel there.'); return; }
    try { const t = await chrome.tabs.update(s.tabId, { active: true }); await chrome.windows.update(t.windowId, { focused: true }); }
    catch (_) { await SS.update(s.id, { status: 'ended', tabId: null, endedAt: Date.now() }); guide('<b>That tab is closed</b>, so the session has ended.'); renderList(); }
  }

  // ---------- Sessions list ----------
  async function renderList() {
    const all = await SS.list();
    const ended = all.filter(s => s.status === 'ended');
    $('n1').textContent = all.length;
    $('n2').textContent = Math.round(ended.reduce((a, s) => a + (s.durationMs || 0), 0) / 60000) + 'm';
    $('n3').textContent = ended.reduce((a, s) => a + (s.creditsUsed || 0), 0);
    const t = $('tbl'); t.textContent = '';
    if (!all.length) { const e = el('div', 'empty'); e.append('No sessions yet. '); const a = el('a', '', 'Create your first session'); a.href = '#new'; e.append(a, '.'); t.appendChild(e); return; }
    const hd = el('div', 'srow h'); ['Title', 'Mode', 'Duration', 'Credits used', 'Date', 'Status', ''].forEach(x => hd.appendChild(el('span', '', x))); t.appendChild(hd);
    all.forEach(s => {
      const r = el('div', 'srow');
      const title = el('a', 't', s.title); title.href = '#session=' + s.id;
      const action = el('button', s.status === 'ready' ? 'primary sm' : 'ghost sm', s.status === 'ready' ? 'Start' : s.status === 'live' ? 'Join' : 'View transcript');
      action.type = 'button';
      action.onclick = () => (s.status === 'ready' ? startSession(s) : s.status === 'live' ? join(s) : (location.hash = '#session=' + s.id + '=transcript'));
      r.append(title, el('span', 'pill', SS.MODE_LABEL[s.mode] || s.mode), el('span', '', minutesOf(s)), el('span', '', s.status === 'ended' && s.creditsUsed != null ? String(s.creditsUsed) : '–'),
        el('span', '', fmtDate(s.createdAt)), el('span', 'st ' + s.status, STATUS[s.status] || s.status), action);
      t.appendChild(r);
    });
  }

  // ---------- New session ----------
  const N = { step: 1, mode: 'interview', minutes: 45 };
  const MODE_NOTE = {
    interview: 'Uses your resume from Documents, plus the job description you add next.',
    call: 'For meetings and client calls. Does not use your resume; uses your notes and playbooks from Documents.',
    mock: 'An AI interviewer asks questions out loud, listens to your answers, asks follow-ups and gives feedback at the end. Practice only, no call needed.',
  };
  function setMode(m) {
    N.mode = m;
    $('nmode').querySelectorAll('button').forEach(b => b.setAttribute('aria-checked', b.dataset.v === m));
    $('nmodeNote').textContent = MODE_NOTE[m];
    $('nroleL').firstChild.textContent = m === 'call' ? 'Your role on the call' : 'Role';
    $('nsave').disabled = m === 'mock';
    if (m === 'mock') $('nsave').checked = true;
    $('nsaveNote').textContent = m === 'mock' ? 'Mock interviews always keep their transcript, so Cue can give feedback.' : 'Transcripts stay in this browser.';
  }
  function setMinutes(m) {
    N.minutes = Math.min(480, Math.max(15, Math.round(+m || 45)));
    $('nmin').value = N.minutes;
    $('nchips').querySelectorAll('button').forEach(b => b.classList.toggle('sel', +b.dataset.m === N.minutes));
  }
  function goStep(n) {
    if (n > 1 && !$('ntitle').value.trim()) { $('ntitle').focus(); $('ntitle').setAttribute('aria-invalid', 'true'); return; }
    $('ntitle').removeAttribute('aria-invalid');
    N.step = n;
    document.querySelectorAll('.wstep').forEach(x => (x.hidden = +x.dataset.step !== n));
    $('wiz').querySelectorAll('li').forEach(li => { li.classList.toggle('on', +li.dataset.s === n); li.classList.toggle('done', +li.dataset.s < n); });
    $('nback').hidden = n === 1; $('nnext').hidden = n === 3;
    if (n === 3) renderQuote();
  }
  const fields = () => ({ title: $('ntitle').value.trim(), company: $('ncompany').value.trim(), role: $('nrole').value.trim(), mode: N.mode, lang: $('nlang').value,
    plannedMinutes: N.minutes, instructions: $('ninst').value.slice(0, 20000), saveTranscript: N.mode === 'mock' || $('nsave').checked });

  let quote = null;
  async function renderQuote() {
    const f = fields();
    const dl = $('nsum'); dl.textContent = '';
    [['Title', f.title], ['Type', SS.MODE_LABEL[f.mode]], ['Company', f.company || '–'], ['Role', f.role || '–'], ['Language', $('nlang').selectedOptions[0].textContent],
      ['Duration', C.dur(f.plannedMinutes)], ['Instructions', f.instructions ? f.instructions.length.toLocaleString() + ' characters' : 'None'], ['Transcript', f.saveTranscript ? 'Saved' : 'Not saved']]
      .forEach(([k, v]) => dl.append(el('dt', '', k), el('dd', '', v)));
    $('nq').textContent = '…'; $('nqs').textContent = ''; $('ngo').disabled = true; $('nmsg').textContent = '';
    try { await account(); } catch (e) { $('nmsg').textContent = e.message; return; }
    const p = acct.pricing, credits = Math.ceil(f.plannedMinutes / p.creditMinutes);
    quote = C.quote(f.plannedMinutes, acct.credits, p);
    $('nq').textContent = `${C.dur(f.plannedMinutes)} = ${credits} credits = ${C.rupees(credits * p.pricePerCreditPaise)}`;
    const free = f.mode === 'mock' && acct.freeMock;
    if (free) {
      $('nqs').textContent = 'Your first mock interview is free for 15 minutes. No payment needed.';
      $('ngo').textContent = 'Start mock interview'; quote = null;
    } else if (quote.buy) {
      const what = quote.buy.pack ? quote.buy.label.replace(/, \d+ credits$/, '') + ` (${quote.buy.credits} credits)` : `${quote.buy.credits} credits`;
      $('nqs').textContent = `${p.creditMinutes} minutes per credit, ${C.rupees(p.pricePerCreditPaise)} each. You have ${acct.credits}. Buy ${what} for ${C.rupees(quote.buy.pricePaise)}. Credits are only used for time actually spent; the rest stays in your balance.`;
      $('ngo').textContent = 'Pay & Start';
    } else {
      $('nqs').textContent = `Covered by your balance of ${acct.credits} credits. Credits are only used for time actually spent; the rest stays in your balance.`;
      $('ngo').textContent = f.mode === 'mock' ? 'Start mock interview' : 'Start';
    }
    $('ngo').disabled = false;
  }

  async function createAndGo(start) {
    $('ngo').disabled = $('nlater').disabled = true;
    const s = await SS.create(fields());
    resetForm();
    if (!start) { location.hash = '#sessions'; guide(`<b>“${escapeHtml(s.title)}” is saved.</b> Press Start when you are ready.`); return; }
    if (quote && quote.buy) {
      try {
        const o = await C.api('/api/billing/order', { body: C.orderBody(quote.buy) });
        chrome.tabs.create({ url: o.payUrl });
        location.hash = '#sessions';
        guide(`<b>Finish paying in the new tab.</b> Then press <b>Start</b> next to “${escapeHtml(s.title)}”. Your session is saved.`);
      } catch (e) { location.hash = '#sessions'; guide(`<b>Could not open checkout:</b> ${escapeHtml(e.message)}. Your session is saved; press Start after adding credits.`); }
      return;
    }
    startSession(s);
  }
  function resetForm() {
    $('newForm').reset(); setMode('interview'); setMinutes(45); $('ncount').textContent = '0 / 20,000';
    $('ngo').disabled = $('nlater').disabled = false; goStep(1);
  }

  $('nmode').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setMode(b.dataset.v); });
  $('nmode').addEventListener('keydown', e => {
    if (!['ArrowRight', 'ArrowLeft'].includes(e.key)) return;
    const bs = [...$('nmode').querySelectorAll('button')], i = bs.findIndex(b => b.dataset.v === N.mode), n = bs[(i + (e.key === 'ArrowRight' ? 1 : bs.length - 1)) % bs.length];
    setMode(n.dataset.v); n.focus();
  });
  $('nchips').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setMinutes(b.dataset.m); });
  $('nmin').addEventListener('change', e => setMinutes(e.target.value));
  $('ninst').addEventListener('input', e => { $('ncount').textContent = `${e.target.value.length.toLocaleString()} / 20,000`; });
  $('nnext').onclick = () => goStep(N.step + 1);
  $('nback').onclick = () => goStep(N.step - 1);
  $('ngo').onclick = () => createAndGo(true);
  $('nlater').onclick = () => createAndGo(false);
  $('newForm').addEventListener('submit', e => e.preventDefault());

  // ---------- Session page ----------
  async function renderSession(id, tab = 'notes') {
    const d = $('sdetail'); d.textContent = '';
    const s = await SS.get(id);
    if (!s) { d.append(el('h1', '', 'Session not found')); const a = el('a', '', 'Back to sessions'); a.href = '#sessions'; d.append(a); return; }
    const back = el('a', 'back', '← Sessions'); back.href = '#sessions';
    const head = el('div', 'titlebar'); head.append(el('h1', '', s.title));
    if (s.status === 'ready') { const b = el('button', 'primary', 'Start'); b.onclick = () => startSession(s); head.append(b); }
    if (s.status === 'live') { const b = el('button', 'primary', 'Join'); b.onclick = () => join(s); head.append(b); }
    const meta = el('p', 'sub', [SS.MODE_LABEL[s.mode], s.company, s.role, minutesOf(s), s.creditsUsed != null ? s.creditsUsed + (s.creditsUsed === 1 ? ' credit used' : ' credits used') : null, fmtDate(s.createdAt), STATUS[s.status]].filter(Boolean).join(' · '));
    const tabs = el('div', 'tabs'); tabs.setAttribute('role', 'tablist');
    const body = el('div', 'tabbody'); body.setAttribute('role', 'tabpanel');
    const T = [['notes', s.mode === 'mock' ? 'Feedback' : 'AI Notes'], ['transcript', 'Transcript'], ['ask', 'Ask AI']];
    T.forEach(([k, label]) => {
      const b = el('button', '', label); b.type = 'button'; b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', k === tab);
      b.onclick = () => { location.hash = '#session=' + id + '=' + k; };
      tabs.append(b);
    });
    d.append(back, head, meta, tabs, body);
    const has = s.transcript && s.transcript.length;
    if (tab === 'notes') {
      if (s.notes) body.append(el('pre', 'notes', s.notes));
      else body.append(el('p', 'note', has ? 'No notes yet.' : s.status === 'ended' ? 'No transcript was saved for this session, so there are no notes.' : 'Notes appear here after the session ends.'));
      if (has) {
        const g = el('button', 'ghost', s.notes ? 'Regenerate notes' : 'Generate AI notes'); g.type = 'button';
        g.onclick = async () => {
          g.disabled = true; g.textContent = 'Writing notes…';
          try { const j = await C.api('/api/notes', { body: { transcript: s.transcript, mode: s.mode === 'call' ? 'call' : 'interview', title: s.title } }); await SS.update(id, { notes: j.notes }); renderSession(id, 'notes'); }
          catch (e) { g.disabled = false; g.textContent = 'Try again'; body.append(el('p', 'note', e.message)); }
        };
        body.append(g);
      }
    } else if (tab === 'transcript') {
      if (!has) body.append(el('p', 'note', s.status === 'ended' ? 'No transcript was saved for this session.' : 'The transcript appears here after the session ends, if saving is on.'));
      else {
        const box = el('div', 'transcript');
        s.transcript.forEach(l => { const line = el('p'); line.append(el('b', l.speaker === 'me' ? 'me' : 'other', l.speaker === 'me' ? 'You' : (s.mode === 'mock' ? 'Interviewer' : 'Other')), document.createTextNode(l.text)); box.append(line); });
        body.append(box);
      }
    } else {
      const thread = el('div', 'thread');
      const draw = () => { thread.textContent = ''; (s.ask || []).forEach(m => thread.append(el('div', 'bubble ' + m.role, m.content))); if (!(s.ask || []).length) thread.append(el('p', 'note', 'Ask anything about this call, for example: “What did they ask about pricing?” or “How could I have answered the first question better?”')); };
      draw();
      const f = el('form', 'askrow'), inp = el('input'); inp.placeholder = 'Ask about this call'; inp.setAttribute('aria-label', 'Ask about this call'); inp.maxLength = 2000;
      const go = el('button', 'primary', 'Ask'); go.type = 'submit';
      f.append(inp, go);
      f.onsubmit = async e => {
        e.preventDefault(); const q = inp.value.trim(); if (!q) return;
        if (!has && !s.notes) { thread.append(el('p', 'note', 'This session has no transcript or notes to ask about.')); return; }
        s.ask = [...(s.ask || []), { role: 'user', content: q }]; inp.value = ''; draw(); go.disabled = true;
        const wait = el('div', 'bubble assistant', 'Thinking…'); thread.append(wait);
        try { const j = await C.api('/api/notes/ask', { body: { transcript: s.transcript || [], notes: s.notes || '', title: s.title, messages: s.ask } }); s.ask.push({ role: 'assistant', content: j.answer }); }
        catch (err) { s.ask.push({ role: 'assistant', content: 'Could not answer: ' + err.message }); }
        await SS.update(id, { ask: s.ask }); draw(); go.disabled = false; inp.focus();
      };
      body.append(thread, f);
    }
    const del = el('button', 'danger', 'Delete session'); del.type = 'button';
    del.onclick = async () => { if (!confirm('Delete this session and its transcript and notes?')) return; await SS.remove(id); location.hash = '#sessions'; };
    d.append(del);
  }

  // ---------- Documents ----------
  const KIND = { resume: 'Resume', notes: 'Notes', playbook: 'Playbook', other: 'Other' };
  async function renderDocs() {
    const docs = await SS.docs(), t = $('dtbl'); t.textContent = '';
    if (!docs.length) { t.append(el('p', 'empty', 'No documents yet. Upload your resume to get answers that sound like you.')); return; }
    const hd = el('div', 'drow h'); ['Name', 'Type', 'Size', ''].forEach(x => hd.append(el('span', '', x))); t.append(hd);
    docs.forEach(doc => {
      const r = el('div', 'drow'), kind = el('select'); kind.setAttribute('aria-label', 'Type of ' + doc.name);
      Object.entries(KIND).forEach(([k, v]) => kind.add(new Option(v, k, false, k === doc.kind)));
      kind.onchange = async () => { const all = await SS.docs(); all.find(x => x.id === doc.id).kind = kind.value; await SS.saveDocs(all); };
      const rm = el('button', 'link', 'Remove'); rm.type = 'button';
      rm.onclick = async () => { await SS.saveDocs((await SS.docs()).filter(x => x.id !== doc.id)); renderDocs(); };
      r.append(el('span', 't', doc.name), kind, el('span', '', Math.round(doc.text.length / 100) / 10 + 'k chars'), rm);
      t.append(r);
    });
  }
  $('files').onchange = async e => {
    const files = [...e.target.files]; if (!files.length) return;
    const docs = await SS.docs(); let added = 0;
    for (const f of files) {
      $('dmsg').textContent = `Reading ${f.name}…`;
      const fd = new FormData(); fd.append('file', f);
      try {
        const r = await C.authFetch('/api/resume', { method: 'POST', body: fd });
        const j = await r.json(); if (!r.ok) throw new Error(j.error);
        if (!j.text) throw new Error('No text found in it.');
        const kind = /resume|cv/i.test(f.name) || (!docs.some(d => d.kind === 'resume') && /experience|education/i.test(j.text.slice(0, 3000))) ? 'resume' : 'notes';
        docs.unshift({ id: 'd' + Date.now().toString(36) + added, name: f.name.replace(/\.(pdf|docx|txt|md)$/i, ''), kind, text: j.text.slice(0, 200000), addedAt: Date.now() });
        added++;
      } catch (err) { $('dmsg').textContent = `${f.name}: ${err.message || 'could not read it'}`; }
    }
    await SS.saveDocs(docs); e.target.value = '';
    if (added) $('dmsg').textContent = `Added ${added} document${added === 1 ? '' : 's'}. Check the type of each one.`;
    renderDocs();
  };

  // ---------- routing ----------
  window.CueOptions = {
    show(page, arg) {
      if (page === 'sessions') renderList();
      if (page === 'new') { if (N.step === 3) renderQuote(); }
      if (page === 'session' && arg) { const [id, tab] = arg.split('='); renderSession(id, tab || (location.hash.split('=')[2]) || 'notes'); }
      if (page === 'documents') renderDocs();
      if (page !== 'sessions') guide('');
    },
  };
  // Keep the list fresh while a session runs in another tab.
  chrome.storage.onChanged.addListener(ch => { if (ch.sessions && (location.hash || '#sessions').startsWith('#sessions')) renderList(); });
  setMode('interview'); setMinutes(45);
  show();
})();
